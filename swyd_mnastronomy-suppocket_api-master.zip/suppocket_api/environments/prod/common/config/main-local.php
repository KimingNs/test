<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=rm-k1armt37dm0y5jmralo.mysql.ap-southeast-5.rds.aliyuncs.com;dbname=db_suppocket',
            'username' => 'wishing',
            'password' => 'Wishing@MnZy89034612',
            'charset' => 'utf8',
        ],
        'db_log' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=rm-k1armt37dm0y5jmralo.mysql.ap-southeast-5.rds.aliyuncs.com;dbname=db_suppocket_log',
            'username' => 'wishing',
            'password' => 'Wishing@MnZy89034612',
            'charset' => 'utf8',
        ],
        'redis' => [
            'class' => 'yii\redis\Connection',
            'hostname' => 'localhost',
            'port' => 6379,
            'database' => 0,
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
        ],
    ],
];
