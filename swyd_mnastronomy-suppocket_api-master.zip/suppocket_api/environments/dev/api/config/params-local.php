<?php
return [
    'loan-api-sites' => 'https://testloanapi.cogitodata.com/',
];
