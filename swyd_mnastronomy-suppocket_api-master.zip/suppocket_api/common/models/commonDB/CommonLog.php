<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/17
 * Time: 下午4:21
 */

namespace common\models\commonDB;


use yii\db\ActiveRecord;

class CommonLog extends ActiveRecord
{
    public static function getDb()
    {
        return \Yii::$app->db_log;
    }
}