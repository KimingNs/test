<?php


namespace common\models\commonDB;


use yii\db\ActiveQuery;


/**
 * Class CommonQuery
 * @package common\models\commonDB
 * @see CommonDB
 */
class CommonQuery extends ActiveQuery
{

}

