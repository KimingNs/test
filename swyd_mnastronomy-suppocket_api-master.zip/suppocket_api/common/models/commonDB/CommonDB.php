<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/17
 * Time: 下午4:19
 */
namespace common\models\commonDB;

use yii\db\ActiveRecord;

class CommonDB extends ActiveRecord
{

}