<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/5/9
 * Time: 上午10:55
 */

namespace common\models;


use yii\db\ActiveRecord;

class UserDeviceMiddle extends ActiveRecord
{
    /**
     * @return string 返回该AR类关联的数据表名
     */
    public static function tableName()
    {
        return 't_user_device_middle';
    }
}