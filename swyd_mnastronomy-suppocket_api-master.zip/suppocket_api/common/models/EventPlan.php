<?php


namespace common\models;


use common\models\commonDB\CommonDB;

class EventPlan extends CommonDB
{
    public static function tableName(): string
    {
        return 't_event_plan';
    }

}