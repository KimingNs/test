<?php


namespace common\models;


use yii\db\ActiveRecord;

class ChuanglanSms extends ActiveRecord
{
    public static function tableName()
    {
        return 't_chuanglan_sms';
    }
}