<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/4
 * Time: 下午6:18
 */

namespace common\models;


use common\models\commonDB\CommonDB;

class AppList extends CommonDB
{
    public static function tableName()
    {
        return 't_app_list';
    }

    //获取所有的APP
    public static function getList()
    {
        $data = AppList::find()->indexBy('app_package')->asArray()->all();
        return $data;
    }

    //格式化后的APP列表
    public static function getAppList()
    {
        $data = static::getList();
        if (empty($data)) {
            return false;
        }
//        $res = [];
//        foreach ($data as $value) {
//            $res[$value['app_package']] = $value;
//        }
        return $data;
    }

    //获取APP名称
    public static function getAppName($package)
    {
        $data = AppList::find()->select(['app_name'])->where('app_package = :package', [':package' => $package])->limit(1)->asArray()->one();
        if (empty($data)) {
            return false;
        }
        return $data['app_name'];
    }
}