<?php


namespace common\models;


use yii\db\ActiveRecord;

/***
 * Class SmsCode
 * @package common\models
 * @property integer $id
 * @property string $app_name
 * @property string $mobile
 * @property string $action
 * @property string $code
 * @property integer $status
 * @property string $ctime
 * @property string $uptime
 */
class SmsCode extends ActiveRecord
{
    public static function tableName()
    {
        return 't_sms_code';
    }

    public static function codeExists($app_name,$mobile,$action,$code)
    {
        $result = self::find()
            ->where(['app_name'=>$app_name,'mobile'=>$mobile,'action'=>$action])
            ->orderBy(['id'=>SORT_DESC])
            ->one();
        if ($result->status == 0 && $result->code == $code) {
            $result->status = 1;
            $result->save();
            return array(true,API_SUCCESS);
        } else {
            return array(false,VALIDATE_ERROR_SMS_CODE);
        }
    }

    public static function lastSms($action,$guid=null,$mobile=null)
    {
        return self::find()
            ->where(['action'=>$action])
            ->andFilterWhere(['guid'=>$guid,'mobile'=>$mobile])
            ->orderBy(['ctime'=>SORT_DESC])
            ->asArray()
            ->one();
    }
}