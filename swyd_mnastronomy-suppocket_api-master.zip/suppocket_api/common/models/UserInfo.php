<?php


namespace common\models;


use yii\db\ActiveRecord;

/**
 * Class UserInfo
 * @package common\models
 * @property integer $id
 * @property string $app_package
 * @property string $user_id
 * @property string $mobile
 * @property string $user_name
 * @property string $password
 * @property string $logo
 * @property string $first_guid
 * @property string $last_guid
 * @property string $last_active
 * @property string $ctime
 * @property string $uptime
 */
class UserInfo extends ActiveRecord
{
    public static function tableName()
    {
        return 't_user_info';
    }

    /**
     * 判断 mobile 是否注册
     * @param $app_package
     * @param $mobile
     * @return boolean
     */
    public static function userExists($app_package,$mobile)
    {
        return self::find()->where(['app_package'=>$app_package,'mobile'=>$mobile])->asArray()->exists();
    }

    public static function userInsert($app_package,$mobile,$password,$guid)
    {
        $user_id = \Yii::$app->api->getUserId($app_package,$mobile);
        $user_name = 'Nick Name';
        $logo = '';
        try {
            $result = self::getDb()->createCommand()->insert(self::tableName(), [
                'app_package' => $app_package,
                'user_id' => $user_id,
                'mobile' => $mobile,
                'user_name' => $user_name,
                'password' => $password,
                'logo' => $logo,
                'first_guid' => $guid,
                'last_guid' => $guid,
                'last_active' => date('Y-m-d H:i:s'),
            ])->execute();
            if ($result == 1) {
                return array(API_SUCCESS,[
                    'user_id' => $user_id,
                    'user_mobile' => $mobile,
                    'user_name' => $user_name,
                    'user_logo' => $logo,
                ]);
            } else {
                return array(API_ERROR_SERVER,[]);
            }
        } catch(\Exception $e) {
            \Yii::error($e);
            return array(API_ERROR_SERVER,[]);
        }
    }

    public static function validatePassword($app_package,$mobile,$password)
    {
        $result = self::find()
            ->select(['user_id','user_mobile'=>'mobile','user_name','user_logo'=>'logo'])
            ->where(['app_package'=>$app_package,'mobile'=>$mobile,'password'=>$password])
            ->asArray()
            ->one();
        if ($result) {
            return array(API_SUCCESS,$result);
        } else {
            return array(VALIDATE_ERROR_PASSWORD,[]);
        }
    }

    public static function editPassword($app_package,$mobile,$password,$guid)
    {
        return self::updateAll(['password'=>$password,'last_guid'=>$guid,'last_active'=>date('Y-m-d H:i:s')],['app_package'=>$app_package,'mobile'=>$mobile]);
    }
}