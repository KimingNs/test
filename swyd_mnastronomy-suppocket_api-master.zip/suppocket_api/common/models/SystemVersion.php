<?php
/**
 * Created by PhpStorm.
 * User: martin
 * Date: 2019/5/9
 * Time: 下午5:12
 */

namespace common\models;

use common\models\commonDB\CommonDB;

class SystemVersion extends CommonDB
{
    public static function tableName()
    {
        return 't_system_version';
    }
}