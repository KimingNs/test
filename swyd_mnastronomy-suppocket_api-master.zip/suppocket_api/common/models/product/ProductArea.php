<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/17
 * Time: 下午4:54
 */

namespace common\models\product;


use common\models\commonDB\CommonDB;

class ProductArea extends CommonDB
{
    /**
     * @return string 返回该AR类关联的数据表名
     */
    public static function tableName()
    {
        return 't_product_area';
    }


    public static function getListCache()
    {
        $data = ProductArea::find()->where('status = 1')->asArray()->all();
        if (empty($data)) {
            return [];
        }
        $cacheProductArea = \Yii::$app->cache->get(CACHE_PRODUCT_AREA);
        if ($cacheProductArea === false) {
            $cacheProductArea = [];
            foreach ($data as $value) {
                $cacheProductArea[$value['id']] = $value['name'];
            }

            try {
                \Yii::$app->cache->set(CACHE_PRODUCT_AREA, $cacheProductArea, 1 * 60 * 60);
            } catch (\Exception $e) {
                \Yii::error($e);
            }
        }
        return $cacheProductArea;
    }

    public static function getListName(array $areaId)
    {
        $area = ProductArea::getListCache();
        $areaName = [];
        foreach ($areaId as $value) {
            if (isset($area[$value])) {
                $areaName[] = $area[$value];
            }
        }
        return $areaName;
    }
}