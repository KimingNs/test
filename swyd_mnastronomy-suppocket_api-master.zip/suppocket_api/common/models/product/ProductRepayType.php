<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/17
 * Time: 下午6:00
 */

namespace common\models\product;

use common\models\commonDB\CommonDB;

class ProductRepayType extends CommonDB
{
    /**
     * @return string 返回该AR类关联的数据表名
     */
    public static function tableName()
    {
        return 't_product_repay_type';
    }


    public static function getListCache()
    {
        $data = ProductRepayType::find()->where('status = 1')->asArray()->all();
        if (empty($data)) {
            return [];
        }
        $cacheProductRepayType = \Yii::$app->cache->get(CACHE_PRODUCT_REPAY_TYPE);
        if ($cacheProductRepayType === false) {
            $cacheProductRepayType = [];
            foreach ($data as $value) {
                $cacheProductRepayType[$value['id']] = $value['name'];
            }

            try {
                \Yii::$app->cache->set(CACHE_PRODUCT_REPAY_TYPE, $cacheProductRepayType, 1 * 60 * 60);
            } catch (\Exception $e) {
                \Yii::error($e);
            }
        }
        return $cacheProductRepayType;
    }

    public static function getListName(array $repayId)
    {
        $repayType = ProductRepayType::getListCache();
        $repayTypeName = [];
        foreach ($repayId as $value) {
            if(isset($repayType[$value])){
                $repayTypeName[] = $repayType[$value];
            }
        }
        return $repayTypeName;
    }
}