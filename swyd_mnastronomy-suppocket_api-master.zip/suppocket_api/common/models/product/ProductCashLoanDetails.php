<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/17
 * Time: 下午5:24
 */

namespace common\models\product;


use common\models\commonDB\CommonDB;

class ProductCashLoanDetails extends CommonDB
{
    /**
     * @return string 返回该AR类关联的数据表名
     */
    public static function tableName()
    {
        return 't_product_cash_loan_details';
    }
}