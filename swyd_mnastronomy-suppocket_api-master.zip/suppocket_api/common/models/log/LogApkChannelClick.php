<?php


namespace common\models\log;


use common\models\commonDB\CommonLog;

class LogApkChannelClick extends CommonLog
{
    public static $tableName;

    public static function tableName()
    {
        if (empty(self::$tableName)) {
            return 't_log_apk_channel_click_' . date('ymd');
        } else {
            return self::$tableName;
        }
    }

    public static function setTableName($ymd)
    {
        self::$tableName = 't_log_apk_channel_click_' . $ymd;
        return self::$tableName;
    }

}