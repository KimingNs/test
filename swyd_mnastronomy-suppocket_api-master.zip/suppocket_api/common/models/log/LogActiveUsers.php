<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/7
 * Time: 下午3:48
 */

namespace common\models\log;

use common\models\commonDB\CommonLog;

class LogActiveUsers extends CommonLog
{
    public static $tableName;

    public static function tableName()
    {
        if (empty(self::$tableName)) {
            return 't_log_active_users_' . date('ymd');
        } else {
            return self::$tableName;
        }
    }

    /**
     * 设置活跃用户
     * @param string $ymd 表名后缀
     */
    public static function setTableName($ymd)
    {
        self::$tableName = 't_log_active_users_' . $ymd;
        return self::$tableName;
    }
}