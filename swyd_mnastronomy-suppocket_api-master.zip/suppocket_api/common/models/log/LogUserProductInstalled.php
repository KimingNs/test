<?php


namespace common\models\log;


use common\models\commonDB\CommonLog;

class LogUserProductInstalled extends CommonLog
{
    public static function tableName()
    {
        return 't_log_user_product_installed';
    }
}