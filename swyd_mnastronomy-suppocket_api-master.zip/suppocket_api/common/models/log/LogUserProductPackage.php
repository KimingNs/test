<?php


namespace common\models\log;


use common\models\commonDB\CommonLog;

class LogUserProductPackage extends CommonLog
{
    public static $tableName;

    public static function tableName()
    {
        if (empty(self::$tableName)) {
            return 't_log_user_product_package_' . date('ymd');
        } else {
            return self::$tableName;
        }
    }

    public static function setTableName($ymd)
    {
        self::$tableName = 't_log_user_product_package_' . $ymd;
        return self::$tableName;
    }

    public static function insertRows($data)
    {
        try {
            self::getDb()->createCommand()->batchInsert(
                't_log_user_product_package_' . date('ymd'),
                [
                    'user_id',
                    'guid',
                    'pid',
                    'product_type',
                    'product_name',
                    'package_name',
                    'action',
                    'app_package',
                ],
                $data
            )->execute();
            return true;
        }catch (\Exception $e) {
            \Yii::error($e->getMessage());
            return false;
        }
    }
}