<?php


namespace common\models\ActiveQuery;


use common\models\commonDB\CommonQuery;

class ProductCashLoanQuery extends CommonQuery
{
    /**
     * @param int $state 状态：0审核，1正常，2下架
     * @return $this
     */
    public function status(int $state = 1): self
    {
        $this->andOnCondition(['status' => $state]);
        return $this;
    }

    /**
     * @param int $state
     * @return $this
     */
    public function apkStatus(int $state = 1): self
    {
        $this->andOnCondition(['apk_status' => $state]);
        return $this;
    }
}