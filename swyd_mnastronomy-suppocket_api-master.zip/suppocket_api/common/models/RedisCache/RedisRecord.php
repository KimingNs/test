<?php


namespace common\models\RedisCache;


use yii\redis\ActiveRecord;

abstract class RedisRecord extends ActiveRecord
{

}