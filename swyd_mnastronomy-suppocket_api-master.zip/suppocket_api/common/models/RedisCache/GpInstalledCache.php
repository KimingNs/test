<?php


namespace common\models\RedisCache;



use yii\redis\ActiveRecord;

class GpInstalledCache extends RedisRecord
{
    public static function primaryKey(): array
    {
        return ['date', 'app_package', 'package_name'];
    }

    public function attributes(): array
    {
        return [
            'date', 'app_package', 'app_name', 'package_name', 'product_name', 'installed_count'
        ];
    }
}