<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/8
 * Time: 上午10:53
 */

namespace common\models;

use common\models\commonDB\CommonDB;

class UserDevicePackage extends CommonDB
{
    //产品名称
    public static $appName;

    /**
     * @param $uid
     */
    public static function setTableName($appName)
    {
        static::$appName = strtolower($appName);
    }

    /**
     * @return string 返回该AR类关联的数据表名
     */
    public static function tableName()
    {
        return 't_user_device_' . static::$appName;
    }
}