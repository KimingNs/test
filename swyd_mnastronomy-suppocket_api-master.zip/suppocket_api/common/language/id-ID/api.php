<?php

//需要翻译的语言
return [
    API_SUCCESS => 'Success',
    API_ERROR_PARAM_EMPTY => 'params is empty.'
];
