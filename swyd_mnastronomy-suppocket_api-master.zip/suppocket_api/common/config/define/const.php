<?php
//API接口语言
defined('API_LANGUAGE') or define('API_LANGUAGE', 'id-ID');

//归因期
defined('INSTALLED_ATTRIBUTION_DAY') or define('INSTALLED_ATTRIBUTION_DAY',7);
defined('ATTRIBUTION_DAY') or define('ATTRIBUTION_DAY',28);
