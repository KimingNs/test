<?php
defined('CACHE_PRODUCT_AREA') or define('CACHE_PRODUCT_AREA', 'cache_product_area'); //产品区域缓存

defined('CACHE_PRODUCT_REPAY_TYPE') or define('CACHE_PRODUCT_REPAY_TYPE', 'cache_product_repay_type'); //产品还款方式