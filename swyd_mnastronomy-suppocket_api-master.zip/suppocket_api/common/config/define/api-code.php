<?php
//API接口所有的CODE码设置
defined('API_SUCCESS') or define('API_SUCCESS', 0); //成功状态码
defined('API_ERROR_PARAM_EMPTY') or define('API_ERROR_PARAM_EMPTY', 1000); //参数为空
defined('API_ERROR_NOT_JSON') or define('API_ERROR_NOT_JSON', 1001); //数据内容不是json格式
defined('API_ERROR_DEVICE_EMPTY') or define('API_ERROR_DEVICE_EMPTY', 1100);//缺少device信息
defined('API_ERROR_GUID') or define('API_ERROR_GUID', 1007);//guid为空或者错误
defined('API_ERROR_SIGN') or define('API_ERROR_SIGN', 1011); //签名错误或为空
defined('API_ERROR_TIMESTAMP') or define('API_ERROR_TIMESTAMP', 1013); //时间戳错误或为空

defined('API_ERROR_CHANNEL') or define('API_ERROR_CHANNEL', 1012); //渠道为空

defined('API_ERROR_PRODUCT_ID') or define('API_ERROR_PRODUCT_ID', 1015); //产品ID错误
defined('API_ERROR_PRODUCT_TYPE') or define('API_ERROR_PRODUCT_TYPE', 1016); //产品类型错误
defined('API_ERROR_CLICK_TYPE') or define('API_ERROR_CLICK_TYPE', 1017); //产品点击类型错误
defined('API_ERROR_APP_PACKAGE') or define('API_ERROR_APP_PACKAGE', 1019); //包名为空

defined('API_ERROR_INTEREST_TEMPLATE') or define('API_ERROR_INTEREST_TEMPLATE', 1020); //产品利息模版错误

defined('API_ERROR_PARAM_VALUE') or define('API_ERROR_PARAM_VALUE', 1024); //参数值错误

defined('API_ERROR_CREATE_GUID') or define('API_ERROR_CREATE_GUID', 1025); //创建GUID失败

defined('API_ERROR_DEVICE') or define('API_ERROR_DEVICE', 1026); //设备信息错误

defined('API_ERROR_DEVICE_PACKAGE') or define('API_ERROR_DEVICE_PACKAGE', 1027); //用户设备包名为空或者格式错误

defined('API_ERROR_VERSION') or define('API_ERROR_VERSION', 1110); //版本号为空

defined('API_ERROR_API_LIMIT') or define('API_ERROR_API_LIMIT', 3032); //接口访问到达频率

defined('API_ERROR_APPTYPE') or define('API_ERROR_APPTYPE', 3033); //

defined('API_ERROR_SERVER') or define('API_ERROR_SERVER', 90001); //服务器错误

/***
 * 第三方接口错误
 */
defined('API_ERROR_SEND_FAIL') or define('API_ERROR_SEND_FAIL', 3001); //短信发送失败

/**
 * app 参数
 */
defined('API_ERROR_PACKAGE') or define('API_ERROR_PACKAGE',2001);   //报名错误
defined('API_ERROR_SORT') or define('API_ERROR_SORT',2002);   //报名错误
defined('API_ERROR_API') or define('API_ERROR_API',2003);   //报名错误

/**
 * 验证用户post参数
 */
defined('VALIDATE_ERROR_MOBILE_EMPTY') or define('VALIDATE_ERROR_MOBILE_EMPTY',4001);   //手机号为空
defined('VALIDATE_ERROR_MOBILE_FORMAT') or define('VALIDATE_ERROR_MOBILE_FORMAT',4002); //手机号格式不正确
defined('VALIDATE_ERROR_MOBILE_EXISTS') or define('VALIDATE_ERROR_MOBILE_EXISTS',4003); //手机号已注册
defined('VALIDATE_ERROR_MOBILE_NOT_EXISTS') or define('VALIDATE_ERROR_MOBILE_NOT_EXISTS',4004); //手机号未注册
defined('VALIDATE_ERROR_SMS_CODE') or define('VALIDATE_ERROR_SMS_CODE',4005); //验证码错误
defined('VALIDATE_ERROR_PASSWORD_EMPTY') or define('VALIDATE_ERROR_PASSWORD_EMPTY',4006); //密码为空
defined('VALIDATE_ERROR_PASSWORD_LENGTH') or define('VALIDATE_ERROR_PASSWORD_LENGTH',4007); //密码长度错误
defined('VALIDATE_ERROR_PASSWORD_FORMAT') or define('VALIDATE_ERROR_PASSWORD_FORMAT',4008); //密码格式错误
defined('VALIDATE_ERROR_PASSWORD') or define('VALIDATE_ERROR_PASSWORD',4009); //密码错误
defined('VALIDATE_ERROR_SMS_TOO_OFTEN') or define('VALIDATE_ERROR_SMS_TOO_OFTEN',4010); //验证码申请频率限制
defined('VALIDATE_ERROR_PLAN') or define('VALIDATE_ERROR_PLAN',4011); //验证码申请频率限制
defined('VALIDATE_ERROR_RECEIVE') or define('VALIDATE_ERROR_RECEIVE',4012); //验证码申请频率限制
//defined('') or define('',);

