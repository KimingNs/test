<?php
return [
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600,
    'channels' => [
        'mobisummer1' => [
            'redirect' => 'http://cdn.sup-pocket.id/product/package/suppocket_ms1.apk',
            'post_back' => 'http://postback.mobisummer.com/aff_lsr?transaction_id={click_id}&token=5b780426-752f-4c60-8d2e-454f711fdecb',
        ],
        'mobisummer2' => [
            'redirect' => 'http://cdn.sup-pocket.id/product/package/suppocket_ms2.apk',
            'post_back' => 'http://postback.mobisummer.com/aff_lsr?transaction_id={click_id}&token=5b780426-752f-4c60-8d2e-454f711fdecb',
        ],
    ],
];
