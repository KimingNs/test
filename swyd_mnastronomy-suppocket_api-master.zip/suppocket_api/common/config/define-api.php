<?php

require __DIR__ . '/../../common/config/define/const.php';
require __DIR__ . '/../../common/config/define/api-code.php';
require __DIR__ . '/../../common/config/define/cache.php';