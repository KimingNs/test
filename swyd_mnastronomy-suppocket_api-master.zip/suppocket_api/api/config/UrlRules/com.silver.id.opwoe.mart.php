<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'idtp-silver/mart/guid' => 'user-device/guids',
    'idtp-silver/mart/plist' => 'products/list',
    'idtp-silver/mart/info' => 'products/infos',
    'idtp-silver/mart/detail' => 'products/details',
    'idtp-silver/mart/uppackage' => 'user-package/up-packages',
    'idtp-silver/mart/productclick' => 'statistic/product-click',
    'idtp-silver/mart/register_sms' => 'user/sign-up-sms',
    'idtp-silver/mart/register' => 'user/sign-up',
    'idtp-silver/mart/login' => 'user/sign-in',
    'idtp-silver/mart/forgotpwd_sms' => 'user/forgot-password-sms',
    'idtp-silver/mart/forgotpwd' => 'user/forgot-password',
    'idtp-silver/mart/banner' => 'products/get-banner',
    'idtp-silver/mart/nlist' => 'products/product-list',
    'idtp-silver/mart/pop_ups' => 'user/sign-up-pop-ups',
    'idtp-silver/mart/upinstall-plan' => 'user-package/install-plan',
    'idtp-silver/mart/upinstall-planreceive' => 'user-package/install-plan-receive'
];

return $data;