<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'moneyfans-guid' => 'user-device/guids',
    'moneyfans-list' => 'products/list',
    'moneyfans-info' => 'products/infos',
    'moneyfans-detail' => 'products/details',
    'moneyfans-uppackage' => 'user-package/up-packages',
    'moneyfans-productclick' => 'statistic/product-click',
    'moneyfans-register_sms' => 'user/sign-up-sms',
    'moneyfans-register' => 'user/sign-up',
    'moneyfans-login' => 'user/sign-in',
    'moneyfans-forgotpwd_sms' => 'user/forgot-password-sms',
    'moneyfans-forgotpwd' => 'user/forgot-password'
];

return $data;