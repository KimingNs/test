<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'm-tp-cash/guid' => 'user-device/guids',
    'm-tp-cash/plist' => 'products/list',
    'm-tp-cash/info' => 'products/infos',
    'm-tp-cash/detail' => 'products/details',
    'm-tp-cash/uppackage' => 'user-package/up-packages',
    'm-tp-cash/productclick' => 'statistic/product-click',
    'm-tp-cash/register_sms' => 'user/sign-up-sms',
    'm-tp-cash/register' => 'user/sign-up',
    'm-tp-cash/login' => 'user/sign-in',
    'm-tp-cash/forgotpwd_sms' => 'user/forgot-password-sms',
    'm-tp-cash/forgotpwd' => 'user/forgot-password',
    'm-tp-cash/banner' => 'products/get-banner',
    'm-tp-cash/nlist' => 'products/product-list',
    'm-tp-cash/pop_ups' => 'user/sign-up-pop-ups'
];

return $data;