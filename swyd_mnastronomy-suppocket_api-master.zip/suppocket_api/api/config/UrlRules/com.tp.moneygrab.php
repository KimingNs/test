<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'money-grab-guid' => 'user-device/guids',
    'money-grab-plist' => 'products/list',
    'money-grab-info' => 'products/infos',
    'money-grab-detail' => 'products/details',
    'money-grab-uppackage' => 'user-package/up-packages',
    'money-grab-productclick' => 'statistic/product-click',
    'money-grab-register_sms' => 'user/sign-up-sms',
    'money-grab-register' => 'user/sign-up',
    'money-grab-login' => 'user/sign-in',
    'money-grab-forgotpwd_sms' => 'user/forgot-password-sms',
    'money-grab-forgotpwd' => 'user/forgot-password'
];

return $data;