<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'id-dana-rakyat-guid' => 'user-device/guids',
    'id-dana-rakyat-plist' => 'products/list',
    'id-dana-rakyat-info' => 'products/infos',
    'id-dana-rakyat-detail' => 'products/details',
    'id-dana-rakyat-uppackage' => 'user-package/up-packages',
    'id-dana-rakyat-productclick' => 'statistic/product-click',
    'id-dana-rakyat-register_sms' => 'user/sign-up-sms',
    'id-dana-rakyat-register' => 'user/sign-up',
    'id-dana-rakyat-login' => 'user/sign-in',
    'id-dana-rakyat-forgotpwd_sms' => 'user/forgot-password-sms',
    'id-dana-rakyat-forgotpwd' => 'user/forgot-password',
    'id-dana-rakyat-banner' => 'products/get-banner',
    'id-dana-rakyat-nlist' => 'products/product-list',
    'id-dana-rakyat-pop_ups' => 'user/sign-up-pop-ups',
    'id-dana-rakyat-upinstall-plan' => 'user-package/install-plan',
    'id-dana-rakyat-upinstall-planreceive' => 'user-package/install-plan-receive'
];

return $data;