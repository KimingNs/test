<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'get_guids' => 'user-device/guids',
    'get_lists' => 'products/list',
    'get_infos' => 'products/infos',
    'get_details' => 'products/details',
    'user_up_package' => 'user-package/up-packages',
    'status_click' => 'statistic/product-click',
    'get_sign_sms' => 'user/sign-up-sms',
    'register_submit' => 'user/sign-up',
    'login' => 'user/sign-in',
    'get_forgot_sms' => 'user/forgot-password-sms',
    'forgot_pwd_submit' => 'user/forgot-password'
];

return $data;