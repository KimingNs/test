<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'id/mancing/point/rupiah/v20/guid' => 'user-device/guids',
    'id/mancing/point/rupiah/v20/plist' => 'products/list',
    'id/mancing/point/rupiah/v20/info' => 'products/infos',
    'id/mancing/point/rupiah/v20/detail' => 'products/details',
    'id/mancing/point/rupiah/v20/uppackage' => 'user-package/up-packages',
    'id/mancing/point/rupiah/v20/productclick' => 'statistic/product-click',
    'id/mancing/point/rupiah/v20/register_sms' => 'user/sign-up-sms',
    'id/mancing/point/rupiah/v20/register' => 'user/sign-up',
    'id/mancing/point/rupiah/v20/login' => 'user/sign-in',
    'id/mancing/point/rupiah/v20/forgotpwd_sms' => 'user/forgot-password-sms',
    'id/mancing/point/rupiah/v20/forgotpwd' => 'user/forgot-password',
    'id/mancing/point/rupiah/v20/banner' => 'products/get-banner',
    'id/mancing/point/rupiah/v20/nlist' => 'products/product-list',
    'id/mancing/point/rupiah/v20/pop_ups' => 'user/sign-up-pop-ups',
    'id/mancing/point/rupiah/v20/upinstall-plan' => 'user-package/install-plan',
    'id/mancing/point/rupiah/v20/upinstall-planreceive' => 'user-package/install-plan-receive'
];

return $data;