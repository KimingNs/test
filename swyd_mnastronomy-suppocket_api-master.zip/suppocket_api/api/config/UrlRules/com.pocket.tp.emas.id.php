<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'v1/id/pocket/emas/guid' => 'user-device/guids',
    'v1/id/pocket/emas/plist' => 'products/list',
    'v1/id/pocket/emas/info' => 'products/infos',
    'v1/id/pocket/emas/detail' => 'products/details',
    'v1/id/pocket/emas/uppackage' => 'user-package/up-packages',
    'v1/id/pocket/emas/productclick' => 'statistic/product-click',
    'v1/id/pocket/emas/register_sms' => 'user/sign-up-sms',
    'v1/id/pocket/emas/register' => 'user/sign-up',
    'v1/id/pocket/emas/login' => 'user/sign-in',
    'v1/id/pocket/emas/forgotpwd_sms' => 'user/forgot-password-sms',
    'v1/id/pocket/emas/forgotpwd' => 'user/forgot-password',
    'v1/id/pocket/emas/banner' => 'products/get-banner',
    'v1/id/pocket/emas/nlist' => 'products/product-list',
    'v1/id/pocket/emas/pop_ups' => 'user/sign-up-pop-ups',
    'v1/id/pocket/emas/upinstall-plan' => 'user-package/install-plan',
    'v1/id/pocket/emas/upinstall-planreceive' => 'user-package/install-plan-receive'
];

return $data;