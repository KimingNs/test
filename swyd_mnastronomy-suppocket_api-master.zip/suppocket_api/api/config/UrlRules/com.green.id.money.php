<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'v12/green-money/id/guid' => 'user-device/guids',
    'v12/green-money/id/plist' => 'products/list',
    'v12/green-money/id/info' => 'products/infos',
    'v12/green-money/id/detail' => 'products/details',
    'v12/green-money/id/uppackage' => 'user-package/up-packages',
    'v12/green-money/id/productclick' => 'statistic/product-click',
    'v12/green-money/id/register_sms' => 'user/sign-up-sms',
    'v12/green-money/id/register' => 'user/sign-up',
    'v12/green-money/id/login' => 'user/sign-in',
    'v12/green-money/id/forgotpwd_sms' => 'user/forgot-password-sms',
    'v12/green-money/id/forgotpwd' => 'user/forgot-password',
    'v12/green-money/id/banner' => 'products/get-banner',
    'v12/green-money/id/nlist' => 'products/product-list',
    'v12/green-money/id/pop_ups' => 'user/sign-up-pop-ups',
    'v12/green-money/id/upinstall-plan' => 'user-package/install-plan',
    'v12/green-money/id/upinstall-planreceive' => 'user-package/install-plan-receive'
];

return $data;