<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'warna-mart/guid' => 'user-device/guids',
    'warna-mart/plist' => 'products/list',
    'warna-mart/info' => 'products/infos',
    'warna-mart/detail' => 'products/details',
    'warna-mart/uppackage' => 'user-package/up-packages',
    'warna-mart/productclick' => 'statistic/product-click',
    'warna-mart/register_sms' => 'user/sign-up-sms',
    'warna-mart/register' => 'user/sign-up',
    'warna-mart/login' => 'user/sign-in',
    'warna-mart/forgotpwd_sms' => 'user/forgot-password-sms',
    'warna-mart/forgotpwd' => 'user/forgot-password'
];

return $data;