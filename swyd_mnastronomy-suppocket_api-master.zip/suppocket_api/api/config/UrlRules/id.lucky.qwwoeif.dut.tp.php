<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'tp/lucky-du/guid' => 'user-device/guids',
    'tp/lucky-du/plist' => 'products/list',
    'tp/lucky-du/info' => 'products/infos',
    'tp/lucky-du/detail' => 'products/details',
    'tp/lucky-du/uppackage' => 'user-package/up-packages',
    'tp/lucky-du/productclick' => 'statistic/product-click',
    'tp/lucky-du/register_sms' => 'user/sign-up-sms',
    'tp/lucky-du/register' => 'user/sign-up',
    'tp/lucky-du/login' => 'user/sign-in',
    'tp/lucky-du/forgotpwd_sms' => 'user/forgot-password-sms',
    'tp/lucky-du/forgotpwd' => 'user/forgot-password',
    'tp/lucky-du/banner' => 'products/get-banner',
    'tp/lucky-du/nlist' => 'products/product-list',
    'tp/lucky-du/pop_ups' => 'user/sign-up-pop-ups',
    'tp/lucky-du/upinstall-plan' => 'user-package/install-plan',
    'tp/lucky-du/upinstall-planreceive' => 'user-package/install-plan-receive'
];

return $data;