<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'v11/tp/tambang-uang/id/guid' => 'user-device/guids',
    'v11/tp/tambang-uang/id/plist' => 'products/list',
    'v11/tp/tambang-uang/id/info' => 'products/infos',
    'v11/tp/tambang-uang/id/detail' => 'products/details',
    'v11/tp/tambang-uang/id/uppackage' => 'user-package/up-packages',
    'v11/tp/tambang-uang/id/productclick' => 'statistic/product-click',
    'v11/tp/tambang-uang/id/register_sms' => 'user/sign-up-sms',
    'v11/tp/tambang-uang/id/register' => 'user/sign-up',
    'v11/tp/tambang-uang/id/login' => 'user/sign-in',
    'v11/tp/tambang-uang/id/forgotpwd_sms' => 'user/forgot-password-sms',
    'v11/tp/tambang-uang/id/forgotpwd' => 'user/forgot-password',
    'v11/tp/tambang-uang/id/banner' => 'products/get-banner',
    'v11/tp/tambang-uang/id/nlist' => 'products/product-list',
    'v11/tp/tambang-uang/id/pop_ups' => 'user/sign-up-pop-ups',
    'v11/tp/tambang-uang/id/upinstall-plan' => 'user-package/install-plan',
    'v11/tp/tambang-uang/id/upinstall-planreceive' => 'user-package/install-plan-receive',
    'v11/tp/tambang-uang/id/getaklist' => 'products/get-ak-list'
];

return $data;