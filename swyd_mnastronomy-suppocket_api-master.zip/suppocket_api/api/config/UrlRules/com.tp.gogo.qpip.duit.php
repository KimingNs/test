<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'go-go-id-duit/guid' => 'user-device/guids',
    'go-go-id-duit/plist' => 'products/list',
    'go-go-id-duit/info' => 'products/infos',
    'go-go-id-duit/detail' => 'products/details',
    'go-go-id-duit/uppackage' => 'user-package/up-packages',
    'go-go-id-duit/productclick' => 'statistic/product-click',
    'go-go-id-duit/register_sms' => 'user/sign-up-sms',
    'go-go-id-duit/register' => 'user/sign-up',
    'go-go-id-duit/login' => 'user/sign-in',
    'go-go-id-duit/forgotpwd_sms' => 'user/forgot-password-sms',
    'go-go-id-duit/forgotpwd' => 'user/forgot-password',
    'go-go-id-duit/banner' => 'products/get-banner',
    'go-go-id-duit/nlist' => 'products/product-list',
    'go-go-id-duit/pop_ups' => 'user/sign-up-pop-ups',
    'go-go-id-duit/upinstall-plan' => 'user-package/install-plan',
    'go-go-id-duit/upinstall-planreceive' => 'user-package/install-plan-receive'
];

return $data;