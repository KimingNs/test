<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'sun-money/guid' => 'user-device/guids',
    'sun-money/plist' => 'products/list',
    'sun-money/info' => 'products/infos',
    'sun-money/detail' => 'products/details',
    'sun-money/uppackage' => 'user-package/up-packages',
    'sun-money/productclick' => 'statistic/product-click',
    'sun-money/register_sms' => 'user/sign-up-sms',
    'sun-money/register' => 'user/sign-up',
    'sun-money/login' => 'user/sign-in',
    'sun-money/forgotpwd_sms' => 'user/forgot-password-sms',
    'sun-money/forgotpwd' => 'user/forgot-password'
];

return $data;