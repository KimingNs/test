<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'id/pohon-emas/guid' => 'user-device/guids',
    'id/pohon-emas/plist' => 'products/list',
    'id/pohon-emas/info' => 'products/infos',
    'id/pohon-emas/detail' => 'products/details',
    'id/pohon-emas/uppackage' => 'user-package/up-packages',
    'id/pohon-emas/productclick' => 'statistic/product-click',
    'id/pohon-emas/register_sms' => 'user/sign-up-sms',
    'id/pohon-emas/register' => 'user/sign-up',
    'id/pohon-emas/login' => 'user/sign-in',
    'id/pohon-emas/forgotpwd_sms' => 'user/forgot-password-sms',
    'id/pohon-emas/forgotpwd' => 'user/forgot-password',
    'id/pohon-emas/banner' => 'products/get-banner',
    'id/pohon-emas/nlist' => 'products/product-list',
    'id/pohon-emas/pop_ups' => 'user/sign-up-pop-ups',
    'id/pohon-emas/upinstall-plan' => 'user-package/install-plan',
    'id/pohon-emas/upinstall-planreceive' => 'user-package/install-plan-receive'
];

return $data;