<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'pj-mart/guid' => 'user-device/guids',
    'pj-mart/list' => 'products/list',
    'pj-mart/info' => 'products/infos',
    'pj-mart/detail' => 'products/details',
    'pj-mart/uppackage' => 'user-package/up-packages',
    'pj-mart/productclick' => 'statistic/product-click',
    'pj-mart/register_sms' => 'user/sign-up-sms',
    'pj-mart/register' => 'user/sign-up',
    'pj-mart/login' => 'user/sign-in',
    'pj-mart/forgotpwd_sms' => 'user/forgot-password-sms',
    'pj-mart/forgotpwd' => 'user/forgot-password'
];

return $data;