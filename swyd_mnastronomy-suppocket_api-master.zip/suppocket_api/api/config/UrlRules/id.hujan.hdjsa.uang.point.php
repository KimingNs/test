<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'id/hujan-uang/v1/guid' => 'user-device/guids',
    'id/hujan-uang/v1/plist' => 'products/list',
    'id/hujan-uang/v1/info' => 'products/infos',
    'id/hujan-uang/v1/detail' => 'products/details',
    'id/hujan-uang/v1/uppackage' => 'user-package/up-packages',
    'id/hujan-uang/v1/productclick' => 'statistic/product-click',
    'id/hujan-uang/v1/register_sms' => 'user/sign-up-sms',
    'id/hujan-uang/v1/register' => 'user/sign-up',
    'id/hujan-uang/v1/login' => 'user/sign-in',
    'id/hujan-uang/v1/forgotpwd_sms' => 'user/forgot-password-sms',
    'id/hujan-uang/v1/forgotpwd' => 'user/forgot-password',
    'id/hujan-uang/v1/banner' => 'products/get-banner',
    'id/hujan-uang/v1/nlist' => 'products/product-list',
    'id/hujan-uang/v1/pop_ups' => 'user/sign-up-pop-ups',
    'id/hujan-uang/v1/upinstall-plan' => 'user-package/install-plan',
    'id/hujan-uang/v1/upinstall-planreceive' => 'user-package/install-plan-receive'
];

return $data;