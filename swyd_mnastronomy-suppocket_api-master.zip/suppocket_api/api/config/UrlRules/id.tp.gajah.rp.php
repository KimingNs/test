<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'gajahrp_guid' => 'user-device/guids',
    'gajahrp_plist' => 'products/list',
    'gajahrp_info' => 'products/infos',
    'gajahrp_detail' => 'products/details',
    'gajahrp_uppackage' => 'user-package/up-packages',
    'gajahrp_productclick' => 'statistic/product-click',
    'gajahrp_register_sms' => 'user/sign-up-sms',
    'gajahrp_register' => 'user/sign-up',
    'gajahrp_login' => 'user/sign-in',
    'gajahrp_forgotpwd_sms' => 'user/forgot-password-sms',
    'gajahrp_forgotpwd' => 'user/forgot-password',
    'gajahrp_get_banner' => 'products/get-banner',
    'gajahrp_new_list' => 'products/product-list',
    'gajahrp_user_pop_ups' => 'user/sign-up-pop-ups'
];

return $data;