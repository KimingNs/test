<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'tp/dana/abadi/id/guid' => 'user-device/guids',
    'tp/dana/abadi/id/plist' => 'products/list',
    'tp/dana/abadi/id/info' => 'products/infos',
    'tp/dana/abadi/id/detail' => 'products/details',
    'tp/dana/abadi/id/uppackage' => 'user-package/up-packages',
    'tp/dana/abadi/id/productclick' => 'statistic/product-click',
    'tp/dana/abadi/id/register_sms' => 'user/sign-up-sms',
    'tp/dana/abadi/id/register' => 'user/sign-up',
    'tp/dana/abadi/id/login' => 'user/sign-in',
    'tp/dana/abadi/id/forgotpwd_sms' => 'user/forgot-password-sms',
    'tp/dana/abadi/id/forgotpwd' => 'user/forgot-password',
    'tp/dana/abadi/id/banner' => 'products/get-banner',
    'tp/dana/abadi/id/nlist' => 'products/product-list',
    'tp/dana/abadi/id/pop_ups' => 'user/sign-up-pop-ups',
    'tp/dana/abadi/id/upinstall-plan' => 'user-package/install-plan',
    'tp/dana/abadi/id/upinstall-planreceive' => 'user-package/install-plan-receive'
];

return $data;