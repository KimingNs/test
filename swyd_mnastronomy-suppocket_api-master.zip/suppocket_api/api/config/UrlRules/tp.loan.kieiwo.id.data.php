<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'loan-data/id-tp/guid' => 'user-device/guids',
    'loan-data/id-tp/plist' => 'products/list',
    'loan-data/id-tp/info' => 'products/infos',
    'loan-data/id-tp/detail' => 'products/details',
    'loan-data/id-tp/uppackage' => 'user-package/up-packages',
    'loan-data/id-tp/productclick' => 'statistic/product-click',
    'loan-data/id-tp/register_sms' => 'user/sign-up-sms',
    'loan-data/id-tp/register' => 'user/sign-up',
    'loan-data/id-tp/login' => 'user/sign-in',
    'loan-data/id-tp/forgotpwd_sms' => 'user/forgot-password-sms',
    'loan-data/id-tp/forgotpwd' => 'user/forgot-password',
    'loan-data/id-tp/banner' => 'products/get-banner',
    'loan-data/id-tp/nlist' => 'products/product-list',
    'loan-data/id-tp/pop_ups' => 'user/sign-up-pop-ups',
    'loan-data/id-tp/upinstall-plan' => 'user-package/install-plan',
    'loan-data/id-tp/upinstall-planreceive' => 'user-package/install-plan-receive'
];

return $data;