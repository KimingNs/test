<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'cash/party/guid' => 'user-device/guids',
    'cash/party/plist' => 'products/list',
    'cash/party/info' => 'products/infos',
    'cash/party/detail' => 'products/details',
    'cash/party/uppackage' => 'user-package/up-packages',
    'cash/party/productclick' => 'statistic/product-click',
    'cash/party/register_sms' => 'user/sign-up-sms',
    'cash/party/register' => 'user/sign-up',
    'cash/party/login' => 'user/sign-in',
    'cash/party/forgotpwd_sms' => 'user/forgot-password-sms',
    'cash/party/forgotpwd' => 'user/forgot-password'
];

return $data;