<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'money-hut-guid' => 'user-device/guids',
    'money-hut-plist' => 'products/list',
    'money-hut-info' => 'products/infos',
    'money-hut-detail' => 'products/details',
    'money-hut-uppackage' => 'user-package/up-packages',
    'money-hut-productclick' => 'statistic/product-click',
    'money-hut-register_sms' => 'user/sign-up-sms',
    'money-hut-register' => 'user/sign-up',
    'money-hut-login' => 'user/sign-in',
    'money-hut-forgotpwd_sms' => 'user/forgot-password-sms',
    'money-hut-forgotpwd' => 'user/forgot-password',
/***    loan api Start     ***/
    'money-loan/get-info' => 'loan-api/product-cash-loan::get-info',    //产品详情
    'money-loan/get-loan-interest' => 'loan-api/product-cash-loan::get-loan-interest',  //机构方借款利息
    'money-loan/get-loan-next-code' => 'loan-api/product-cash-loan::get-loan-next-code',    //下一步流程 code
    'money-loan/basic-info' => 'loan-api/loan-page::basic-info',    //填写基础信息
    'money-loan/user-info' => 'loan-api/loan-page::user-info',  //填写用户信息
    'money-loan/company-info' => 'loan-api/loan-page::company-info',    //填写公司信息
    'money-loan/contact-info' => 'loan-api/loan-page::contact-info',    //填写联系人信息
    'money-loan/live-info' => 'loan-api/loan-page::live-info',  //填写居住信息
    'money-loan/student-info' => 'loan-api/loan-page::student-info',    //填写学生信息
    'money-loan/company-student-info' => 'loan-api/loan-page::company-student-info',    //填写公司或学生信息
    'money-loan/other' => 'loan-api/loan-page::other',  //填写其它信息
    'money-loan/bind-bank' => 'loan-api/loan-page::bind-bank',  //活体检测
    'money-loan/biopsy' => 'loan-api/loan-page::biopsy',    //活体检测
    'money-loan/confirm' => 'loan-api/loan-page::confirm',  //确认合同
    'money-loan/get-device-conf' => 'loan-api/loan-page::get-device-conf',  //获取机构的设备信息配置
    'money-loan/submit-basic-info' => 'loan-api/loan-order::basic-info',    //提交基础信息
    'money-loan/submit-supplement-info' => 'loan-api/loan-order::supplement-info',  //提交补充信息
    'money-loan/submit-biopsy-info' => 'loan-api/loan-order::biopsy-info',  //提交订单的补充信息（活体检测）
    'money-loan/submit-order-confirm' => 'loan-api/loan-order::order-confirm',  //订单确认接口
    'money-loan/order-approval-result' => 'loan-api/loan-order-details::order-approval-result',  //订单审批结论
    'money-loan/order-repay-plan' => 'loan-api/loan-order-details::order-repay-plan',   //获取订单还款账单
    'money-loan/get-repay-method' => 'loan-api/loan-order-details::get-repay-method',   //获取订单还款方式
    'money-loan/order-repay-details' => 'loan-api/loan-order-details::order-repay-details',    //获取订单还款详情
    'money-loan/submit-device-info' => 'loan-api/loan-order-device::device-info',     //上传订单设备信息
    'money-loan/order-list' => 'loan-api/loan-order-list::order-list',    //获取用户的订单列表
    'money-loan/get-provinces' => 'loan-api/address::get-provinces',     //获取省份
    'money-loan/get-city' => 'loan-api/address::get-city',      //获取城市
    'money-loan/get-districts' => 'loan-api/address::get-districts', //获取区域
    'money-loan/get-villages' => 'loan-api/address::get-villages',  //获取村落
/***    loan api End    ***/
];

return $data;