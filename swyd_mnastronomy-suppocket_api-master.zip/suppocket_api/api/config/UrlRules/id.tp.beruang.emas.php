<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'beruang/emas-guid' => 'user-device/guids',
    'beruang/emas-plist' => 'products/list',
    'beruang/emas-info' => 'products/infos',
    'beruang/emas-detail' => 'products/details',
    'beruang/emas-uppackage' => 'user-package/up-packages',
    'beruang/emas-productclick' => 'statistic/product-click',
    'beruang/emas-register_sms' => 'user/sign-up-sms',
    'beruang/emas-register' => 'user/sign-up',
    'beruang/emas-login' => 'user/sign-in',
    'beruang/emas-forgotpwd_sms' => 'user/forgot-password-sms',
    'beruang/emas-forgotpwd' => 'user/forgot-password',
    'beruang/emas-banner' => 'products/get-banner',
    'beruang/emas-nlist' => 'products/product-list',
    'beruang/emas-pop_ups' => 'user/sign-up-pop-ups',
    'beruang/emas-upinstall-plan' => 'user-package/install-plan',
    'beruang/emas-upinstall-planreceive' => 'user-package/install-plan-receive',
    'beruang/emas-getaklist' => 'products/get-ak-list'
];

return $data;