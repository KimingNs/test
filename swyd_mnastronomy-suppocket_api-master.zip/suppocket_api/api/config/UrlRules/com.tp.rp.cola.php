<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'rpcola_guid' => 'user-device/guids',
    'rpcola_plist' => 'products/list',
    'rpcola_info' => 'products/infos',
    'rpcola_detail' => 'products/details',
    'rpcola_uppackage' => 'user-package/up-packages',
    'rpcola_productclick' => 'statistic/product-click',
    'rpcola_register_sms' => 'user/sign-up-sms',
    'rpcola_register' => 'user/sign-up',
    'rpcola_login' => 'user/sign-in',
    'rpcola_forgotpwd_sms' => 'user/forgot-password-sms',
    'rpcola_forgotpwd' => 'user/forgot-password',
    'rpcola_banner' => 'products/get-banner',
    'rpcola_nlist' => 'products/product-list',
    'rpcola_pop_ups' => 'user/sign-up-pop-ups'
];

return $data;