<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'id/lr/v10/guid' => 'user-device/guids',
    'id/lr/v10/plist' => 'products/list',
    'id/lr/v10/info' => 'products/infos',
    'id/lr/v10/detail' => 'products/details',
    'id/lr/v10/uppackage' => 'user-package/up-packages',
    'id/lr/v10/productclick' => 'statistic/product-click',
    'id/lr/v10/register_sms' => 'user/sign-up-sms',
    'id/lr/v10/register' => 'user/sign-up',
    'id/lr/v10/login' => 'user/sign-in',
    'id/lr/v10/forgotpwd_sms' => 'user/forgot-password-sms',
    'id/lr/v10/forgotpwd' => 'user/forgot-password',
    'id/lr/v10/banner' => 'products/get-banner',
    'id/lr/v10/nlist' => 'products/product-list',
    'id/lr/v10/pop_ups' => 'user/sign-up-pop-ups',
    'id/lr/v10/upinstall-plan' => 'user-package/install-plan',
    'id/lr/v10/upinstall-planreceive' => 'user-package/install-plan-receive',
    'id/lr/v10/getaklist' => 'products/get-ak-list'
];

return $data;