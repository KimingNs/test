<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'rphomeguids' => 'user-device/guids',
    'rphomelist' => 'products/list',
    'rphomeinfos' => 'products/infos',
    'rphomedetails' => 'products/details',
    'rphomeuppackages' => 'user-package/up-packages',
    'rphomeproductclick' => 'statistic/product-click',
    'rphomesignupsms' => 'user/sign-up-sms',
    'rphomesignup' => 'user/sign-up',
    'rphomesignin' => 'user/sign-in',
    'rphomeforgotpwdsms' => 'user/forgot-password-sms',
    'rphomeforgotpwd' => 'user/forgot-password'
];

return $data;