<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'stationrp-guid' => 'user-device/guids',
    'stationrp-plist' => 'products/list',
    'stationrp-info' => 'products/infos',
    'stationrp-detail' => 'products/details',
    'stationrp-uppackage' => 'user-package/up-packages',
    'stationrp-productclick' => 'statistic/product-click',
    'stationrp-register_sms' => 'user/sign-up-sms',
    'stationrp-register' => 'user/sign-up',
    'stationrp-login' => 'user/sign-in',
    'stationrp-forgotpwd_sms' => 'user/forgot-password-sms',
    'stationrp-forgotpwd' => 'user/forgot-password'
];

return $data;