<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'money/tp/engine/guid' => 'user-device/guids',
    'money/tp/engine/plist' => 'products/list',
    'money/tp/engine/info' => 'products/infos',
    'money/tp/engine/detail' => 'products/details',
    'money/tp/engine/uppackage' => 'user-package/up-packages',
    'money/tp/engine/productclick' => 'statistic/product-click',
    'money/tp/engine/register_sms' => 'user/sign-up-sms',
    'money/tp/engine/register' => 'user/sign-up',
    'money/tp/engine/login' => 'user/sign-in',
    'money/tp/engine/forgotpwd_sms' => 'user/forgot-password-sms',
    'money/tp/engine/forgotpwd' => 'user/forgot-password',
    'money/tp/engine/banner' => 'products/get-banner',
    'money/tp/engine/nlist' => 'products/product-list',
    'money/tp/engine/pop_ups' => 'user/sign-up-pop-ups'
];

return $data;