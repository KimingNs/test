<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'getguid' => 'user-device/guids',
    'list' => 'products/list',
    'infos' => 'products/infos',
    'details' => 'products/details',
    'uppackage' => 'user-package/up-packages',
    'statclick' => 'statistic/product-click',
    'signupsms' => 'user/sign-up-sms',
    'signup' => 'user/sign-up',
    'signin' => 'user/sign-in',
    'forgotsms' => 'user/forgot-password-sms',
    'forgotpwd' => 'user/forgot-password'
];

return $data;