<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'cogito/danasolusi/id/v10/guid' => 'user-device/guids',
    'cogito/danasolusi/id/v10/plist' => 'products/list',
    'cogito/danasolusi/id/v10/info' => 'products/infos',
    'cogito/danasolusi/id/v10/detail' => 'products/details',
    'cogito/danasolusi/id/v10/uppackage' => 'user-package/up-packages',
    'cogito/danasolusi/id/v10/productclick' => 'statistic/product-click',
    'cogito/danasolusi/id/v10/register_sms' => 'user/sign-up-sms',
    'cogito/danasolusi/id/v10/register' => 'user/sign-up',
    'cogito/danasolusi/id/v10/login' => 'user/sign-in',
    'cogito/danasolusi/id/v10/forgotpwd_sms' => 'user/forgot-password-sms',
    'cogito/danasolusi/id/v10/forgotpwd' => 'user/forgot-password',
    'cogito/danasolusi/id/v10/banner' => 'products/get-banner',
    'cogito/danasolusi/id/v10/nlist' => 'products/product-list',
    'cogito/danasolusi/id/v10/pop_ups' => 'user/sign-up-pop-ups',
    'cogito/danasolusi/id/v10/upinstall-plan' => 'user-package/install-plan',
    'cogito/danasolusi/id/v10/upinstall-planreceive' => 'user-package/install-plan-receive'
];

return $data;