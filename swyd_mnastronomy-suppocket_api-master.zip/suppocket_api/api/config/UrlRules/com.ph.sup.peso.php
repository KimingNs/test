<?php
$data = [
    //接口映射模版
    'test/test' => 'test/index',
    'sup-peso-guid' => 'user-device/guids',
    'sup-peso-plist' => 'products/list',
    'sup-peso-info' => 'products/infos',
    'sup-peso-detail' => 'products/details',
    'sup-peso-uppackage' => 'user-package/up-packages',
    'sup-peso-productclick' => 'statistic/product-click',
    'sup-peso-register_sms' => 'user/sign-up-sms',
    'sup-peso-register' => 'user/sign-up',
    'sup-peso-login' => 'user/sign-in',
    'sup-peso-forgotpwd_sms' => 'user/forgot-password-sms',
    'sup-peso-forgotpwd' => 'user/forgot-password'
];

return $data;