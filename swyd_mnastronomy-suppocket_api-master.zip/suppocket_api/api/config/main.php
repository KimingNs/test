<?php
$params = array_merge(
    require __DIR__ . '/../../common/config/params.php',
    require __DIR__ . '/../../common/config/params-local.php',
    require __DIR__ . '/params.php',
    require __DIR__ . '/params-local.php'
);

//加载马甲包路由规则
$data = scandir(__DIR__ . '/UrlRules');
unset($data[0]);
unset($data[1]);
$rules = [];
foreach ($data as $value) {
    $urlConfig = require(__DIR__ . '/UrlRules/' . $value);
    if (!empty($urlConfig) && is_array($urlConfig)) {
        foreach ($urlConfig as $keyUrl => $valueUrl) {
            $rules[$keyUrl] = $valueUrl;
        }
    }
}


return [
    'id' => 'app-api',
    'basePath' => dirname(__DIR__),
    'controllerNamespace' => 'api\controllers',
    'bootstrap' => ['log'],
    'modules' => [],
    'components' => [
        'request' => [
            'csrfParam' => '_csrf-api',
            'parsers' => [
                'application/json' => 'yii\web\JsonParser',
            ]
        ],
        'user' => [
            'identityClass' => 'common\models\User',
            'enableAutoLogin' => true,
            'identityCookie' => ['name' => '_identity-api', 'httpOnly' => true],
        ],
        'session' => [
            // this is the name of the session cookie used for login on the backend
            'name' => 'advanced-api',
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error'],
                    'logFile' => '@api/runtime/logs/' . date('Y-m-d') . '/api_error.log',
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['warning'],
                    'logFile' => '@api/runtime/logs/' . date('Y-m-d') . '/api_warning.log',
                ],
            ],
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],
        'i18n' => [
            'translations' => [
                //api接口语言包
                'api' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@common/language',
                    'fileMap' => [
                        'api' => 'api.php',
                    ],
                ],
            ],
        ],
        //增加组件配置
        'api' => [
            'class' => 'api\component\Api'
        ],
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => $rules,
        ],
        'sms' => [
            'class' => 'api\component\Sms'
        ],
        'validate' => [
            'class' => 'api\component\Validate'
        ],
        'ChuanglanSms' => [
            'class' => 'api\component\ChuanglanSmsApi'
        ],
    ],
    'params' => $params,
];



