<?php

namespace api\component;

use yii\base\Component;

class Api extends Component
{

    /**
     * 生成签名
     * @param string $key
     * @param array $params
     * @param int $timestamp
     * @return string
     */
    public function getSign($key, $params, $timestamp)
    {
        unset($params['sign']); //删除token键名
        unset($params['timestamp']); //删除timestamp键名
        ksort($params); //参数排序
        $md5 = md5(md5($key . '*|*' . json_encode($params) . '@!@' . $timestamp));
        return $md5;
    }

    /**
     * 生成GUID
     * @param $params
     * @return bool|string
     */
    public function getGuid($params)
    {
        if (!empty($params['imei'])) {
            $guid = md5($params['imei']);
        } else if (!empty($params['andId'])) {
            $guid = md5($params['andId']);
        } else if (!empty($params['gaid'])) {
            $guid = md5($params['gaid']);
        } else {
            $guid = md5(uniqid('user_id_',true) . random_int(1, 999999));
        }

        return $guid;
    }

    public function getUserId($package,$mobile)
    {
        return md5($package . $mobile . uniqid());
    }

    /**
     * @param $url
     * @param string $guid
     * @param string $android_id
     * @param string $gaid
     * @param string $site_id
     * @param string $sub_id
     * @return mixed
     */
    public function getAfLink($url, $guid = '', $android_id = '', $gaid = '', $site_id = '', $sub_id = '')
    {
        if(strpos($url, 'play.google') !== false){
            return $url;
        }
        $af_url = str_replace('{android_id}', $android_id, $url);
        $af_url = str_replace('{af_siteid}', '5d1db6ee3ec83325', $af_url);
        $af_url = str_replace('{clickid}', $guid, $af_url);
        $af_url = str_replace('{advertising_id}', $gaid, $af_url);
        $af_url = str_replace('{idfa}', '', $af_url);
        $af_url = str_replace('{sub_id1}', $sub_id, $af_url);
        $af_url = str_replace('{sub_id2}', $site_id, $af_url);
        return $af_url;
    }
}