<?php


namespace api\component;


use common\models\SmsCode;
use yii\base\Component;

class Sms extends Component
{
//    const API_URL = 'http://113.28.178.135:20003/sendsms?account=%s&password=%s&numbers=%s&content=%s';
    const API_URL = 'http://http.mvno.hk:20003/sendsms?account=%s&password=%s&numbers=%s&content=%s';
    const SMS_USER = 'CA0328103-01';
    const SMS_PWD = '7dhJ6wj';

    public function sendCode($guid,$app_name,$mobile,$action)
    {
        //  检测近期是否发送验证码
        $time = date('Y-m-d H:i:s',strtotime('-60 seconds'));
        $last_guid_sms = SmsCode::lastSms($action,$guid,null);
        $last_mobile_sms = SmsCode::lastSms($action,null,$mobile);
        if ((isset($last_guid_sms) && $last_guid_sms['ctime']>$time) || (isset($last_mobile_sms) && $last_mobile_sms['ctime']>$time)) {
            return VALIDATE_ERROR_SMS_TOO_OFTEN;
        }

        //  发送内容
        $code = $this->getCode();
        $content = sprintf('[%s] %s', $app_name, $code);
        $url = sprintf(self::API_URL, self::SMS_USER, self::SMS_PWD, $mobile, $content);

        //  发送验证码
        $result = $this->send($url);
        if ($result == API_SUCCESS) {
            try {
                \Yii::$app->db->createCommand()->insert(SmsCode::tableName(), [
                    'guid' => $guid,
                    'app_name' => $app_name,
                    'mobile' => $mobile,
                    'action' => $action,
                    'code' => $code,
                ])->execute();
            } catch (\Exception $e) {
                \Yii::error($e->getMessage());
                return API_ERROR_SEND_FAIL;
            }
        }
        return $result;
    }

    private function getCode()
    {
        return random_int(100000,999999);
    }

    private function send($url)
    {
        $client = new \GuzzleHttp\Client();
        $response = $client->request('GET',$url);
        $resultBody = $response->getBody()->getContents();
        $result = \GuzzleHttp\json_decode($resultBody,true);
        if ($result['status'] == 0) {
            return API_SUCCESS;
        } else {
            return API_ERROR_SEND_FAIL;
        }
    }

}