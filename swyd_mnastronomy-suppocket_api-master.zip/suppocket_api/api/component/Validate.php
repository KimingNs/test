<?php


namespace api\component;


use yii\base\Component;

class Validate extends Component
{
    /**
     * @param string $mobile
     * @return array($mobile,api-code)
     */
    public function mobile($mobile)
    {
        if (empty($mobile)) {
            return array(null,VALIDATE_ERROR_MOBILE_EMPTY);
        }
        if (preg_match('/^(\+)?(0){0,2}(62)?8[0-9]{9,12}$/',$mobile) !== 1) {
            return array(null,VALIDATE_ERROR_MOBILE_FORMAT);
        }

        $mobile = preg_replace('/^(\+)?(0){0,2}(62)?8/','628',$mobile,1);
        return array($mobile,API_SUCCESS);
    }

    public function password($password)
    {
        if (empty($password)) {
            return array(false,VALIDATE_ERROR_PASSWORD_EMPTY,'password not empty');
        }
        $len = strlen($password);
        if ($len<6 || $len>16) {
            return array(false,VALIDATE_ERROR_PASSWORD_LENGTH,'password length 6 to 16');
        }
        if (preg_match('/^[a-zA-Z0-9]{6,16}$/',$password) !== 1) {
            return array(false,VALIDATE_ERROR_PASSWORD_FORMAT,'password format error');
        }
        return array(true,API_SUCCESS,'');
    }

}