<?php
/**
 * Created by PhpStorm.
 * User: martin
 * Date: 2019/5/9
 * Time: 下午5:25
 */

namespace api\controllers;


use common\models\SystemVersion;

class VersionController extends ApiRest
{
    public function actionIndex()
    {
        //获取POST提交过来的数据
        $params = static::$params;

        if (empty($params['versionNo']) || empty($params['os'])) {
            return $this->setFormatData(API_ERROR_PARAM_EMPTY);
        }
        $versionNo = $params['versionNo'];
        $os = $params['os'];
        $now = date('Y-m-d H:i:s');
//        $appChannel = $this->getChannelType(static::$channel);
        $appChannel = static::$channel;
        $varsion = new SystemVersion();
        $versionData = $varsion::find()
            ->select(['title', 'desc', 'type', 'version_name as version_no', 'url'])
            ->where('version_no>:versionno and os=:os and push_date<=:now and channel=:channel and app_package=:package',
                array(':versionno' => $versionNo, ':os' => $os, ':now' => $now, ':channel' => $appChannel, ':package'=>static::$appPackage))
            ->orderBy('version_no asc')
            ->asArray()
            ->all();
        if (empty($versionData)) {
            //return $this->setRestData(API_ERROR_NOUPDATE, null);
            $versionData = array('title' => '', 'desc' => '', 'type' => 0, 'version_no' => '', 'url' => '');
            return $this->setFormatData(API_SUCCESS, $versionData);
        } else {
            foreach ($versionData as $key => $item) {
                if ($item['type'] == 1) {
                    $mustItem = $item;
                }
            }
            $lastItem = $versionData[count($versionData) - 1];
            if (!empty($mustItem)) {
                $lastItem['type'] = $mustItem['type'];
            }
            return $this->setFormatData(API_SUCCESS, $lastItem);
        }
    }

//    private function getChannelType($channel){
//        $resultChannel = 'app';
//        //判断是否是预装渠道
//        $preInstall = GetFlowChannel::find()
//            ->where('f_channel_name=:channel', [':channel'=>$channel])
//            ->count();
//        if($preInstall>0){
//            $resultChannel = $channel;
//        }
//        return $resultChannel;
//    }
}