<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/04/07
 * Time: 下午4:22
 */

namespace api\controllers;

use common\models\ActiveQuery\ProductCashLoanQuery;
use common\models\AppList;
use common\models\product\ProductArea;
use common\models\product\ProductResource;
use common\models\product\ProductCashLoan;
use common\models\product\ProductCashLoanDetails;
use common\models\product\ProductCashLoanInterestTemplate;
use common\models\product\ProductRepayType;
use common\models\UserDevice;
use Yii;

class ProductsController extends ApiRest
{
    /**
     * [actionGetList 首页排序]
     * @return [type] [description]
     */
    public function actionList()
    {
        //请求参数
        $start = isset(static::$params['start']) ? intval(static::$params['start']) : 0;
//        $limit = isset(static::$params['limit']) ? intval(static::$params['limit']) : 10;
        $limit = 100;

        //更新gaid
        ProductCashLoan::updateGaid(static::$guid, static::$params['deviceInfo']['gaid']);

        $apk_status = null;
        $is_gp = AppList::find()->select(['is_gp'])->where(['app_package'=>static::$appPackage])->asArray()->scalar();
        if($is_gp === '2'){
            $data = ProductCashLoan::getHomeListOnlyGP(static::$guid, static::$appCdn);
            return $this->setFormatData(API_SUCCESS, $data);
        }
        if ($is_gp === '1') {
            $apk_status = 0;
        }
        if ($is_gp === false) {
            return $this->setFormatData(API_ERROR_PACKAGE,'','error package');
        }
        $data = ProductCashLoan::getHomeList(static::$guid, static::$userId, static::$appCdn, $apk_status, $start, $limit, self::$appPackage);

        /** 剔除达到cap的产品 */
        $product_list_cap = [];
        foreach ($data as $item) {
            if($item['capLimit'] > 0){
                //获取实时安装
                $realtimeCount = ProductCashLoan::getProductRealtimeInstalls($item['packageName'], date('Y-m-d'));
                if($realtimeCount < $item['capLimit']){
                    $product_list_cap[] = $item;
                }
            }else{
                $product_list_cap[] = $item;
            }
        }
        $data = $product_list_cap;
        return $this->setFormatData(API_SUCCESS, $data);
    }

    /** 新的 首页排序 （使用中） */
    public function actionProductList()
    {
        $sort = \Yii::$app->request->post('sort','sort');
        if (!in_array($sort, ['sort', 'fast_sort', 'new_sort', 'recommend_sort'])) {
            return $this->setFormatData(API_ERROR_SORT, '', 'error sort');
        }
        $app_list = AppList::find()->select(['is_gp', 'is_api'])->where(['app_package'=>static::$appPackage])->asArray()->one();
        if ($app_list === null) {
            return $this->setFormatData(API_ERROR_PACKAGE,'','error package');
        }

        if($sort === 'sort'){
            //更新gaid
            ProductCashLoan::updateGaid(static::$guid, static::$params['deviceInfo']['gaid']);
        }

        /* 根据 马甲包 GP状态，查询展示的 产品列表 */
        $productCashLoan = ProductCashLoan::find();
        /* 查询字段 */
        if ($sort === 'recommend_sort') {   //推荐排序
            $productCashLoan = $productCashLoan->select(['product_name', 'icon', 'jump_url', 'apk_status', 'package_name', 'cap_limit as capLimit']);
        } else {
            $productCashLoan = $productCashLoan->select([
                'id',
                'appid',
                'product_name as productName',
                'interest_rate as interestRate',
                'interest_rate_unit as interestRateUnit',
                'loan_time_day as loanDay',
                'price_min as priceMin',
                'price_max as priceMax',
                'price_unit as priceUnit',
                'icon',
                'total_score as totalScore',
                'review',
                'package_name as packageName',
                'api_status',
                'cap_limit as capLimit',
            ]);
        }
        /* 查询规则 */
        switch ($app_list['is_gp']) {
            case '2': //GP审核中
                $productCashLoan = $productCashLoan->andWhere(['id' => [281, 287, 288, 289, 290]]); //只显示这五个产品
                break;
            case '1': //GP在线
                $productCashLoan = $productCashLoan->apkStatus(0); //只显示 APK 关闭的
            default:
                $productCashLoan = $productCashLoan->status();
        }
        /* @var ProductCashLoanQuery $productCashLoan */
        /* @var array $product_list  需要展示的产品列表(未通过用户排序) */
        $product_list = $productCashLoan
            ->andWhere(['>', $sort, 0])
            ->andWhere(['like', 'show_apps', self::$appPackage])
            ->orderBy("api_status DESC, $sort ASC, method_sort DESC")->asArray()->all();

        /** @var array $user_installed_package  用户安装的产品 */
        $user_installed_package = UserDevice::installedPackage(static::$guid);

        /** 产品列表 ==> 替换CDN & 用户已安装的产品放最后 */
        foreach ($product_list as $key => $item) {
            //获取实时安装 剔除达到cap的产品
            $packageName = $sort === 'recommend_sort' ? $item['package_name'] : $item['packageName'];
            $realtimeCount = ProductCashLoan::getProductRealtimeInstalls($packageName, date('Y-m-d'));
            if($item['capLimit'] > 0 && $realtimeCount >= $item['capLimit']){
                unset($product_list[$key]);
                continue;
            }
            /* 替换 CDN 地址 */
            if (!empty(static::$appCdn) && isset($item['icon'])) {
                $product_list[$key]['icon'] = ProductCashLoan::replaceCdn($item['icon'], static::$appCdn);
            }
            /* 已安装产品排在后面 */
            if ($user_installed_package !== [] && $item['api_status'] !== '1' && !empty($item['packageName']) && in_array($item['packageName'], $user_installed_package, true)) {
                $product_list[] = $item;
                unset($product_list[$key]);
            }
        }

//        /** 剔除达到cap的产品 */
//        $product_list_cap = [];
//        foreach ($product_list as $item) {
//            if($item['capLimit'] > 0){
//                //获取实时安装
//                $realtimeCount = ProductCashLoan::getProductRealtimeInstalls($item['packageName'], date('Y-m-d'));
//                if($realtimeCount < $item['capLimit']){
//                    $product_list_cap[] = $item;
//                }
//            }else{
//                $product_list_cap[] = $item;
//            }
//        }
//        $product_list = $product_list_cap;

        /* 推荐排序只需要 3 个*/
        if ($sort === 'recommend_sort') {
            $product_list = array_slice($product_list,0,3);
            foreach ($product_list as $key => $product) {
                $product_list[$key]['jump_url'] = Yii::$app->api->getAfLink($product['jump_url'], static::$guid, static::$androidId, static::$params['deviceInfo']['gaid'], static::$appSiteid);
            }
        }

        $product_list = array_values($product_list);
        return $this->setFormatData(API_SUCCESS, $product_list);
    }

    /**
     * 获取产品的详情
     * @return array
     */
    public function actionInfos()
    {
        if (empty(self::$params['pid'])) {
            return $this->setFormatData(API_ERROR_PRODUCT_ID);
        }

        $pid = self::$params['pid'];
        //获取产品基本信息
        $product = ProductCashLoan::find()
            ->select([
                'id as pid',
                'product_name as product_name',
                'price_min',
                'price_max',
                'icon as icon',
                'jump_url as jump_url',
                'pass_rate_score as pass_rate_score',
                'speed_score as speed_score',
                'dunning_score as dunning_score',
                'total_score as total_score',
                'package_name as package_name',
                'apk_status',
                'loan_description',
            ])->where('id = :id', [':id' => $pid])->limit(1)->asArray()->one();
        if (empty($product)) {
            return $this->setFormatData(API_ERROR_PRODUCT_ID);
        }

        //获取产品利息计算的模版
        $interestTemplate = ProductCashLoanInterestTemplate::find()
            ->select([
                'loan_amount as loan_amount',
                'repay_amount as repay_amount',
                'interest_amount as interest_amount',
                'admin_amount as admin_amount',
                '(interest_amount+admin_amount) as interest_admin',
                'cycle'
            ])
            ->where('pid = :id', [':id' => $pid])->limit(1)->asArray()->one();
        $interestTemplate['loan_amount'] = number_format($interestTemplate['loan_amount'], 0, ',', '.');
        $interestTemplate['repay_amount'] = number_format($interestTemplate['repay_amount'], 0, ',', '.');
        $interestTemplate['interest_amount'] = number_format($interestTemplate['interest_amount'], 0, ',', '.');
        $interestTemplate['admin_amount'] = number_format($interestTemplate['admin_amount'], 0, ',', '.');
        $interestTemplate['interest_admin'] = number_format($interestTemplate['interest_admin'], 0, ',', '.');

        if (empty($interestTemplate)) {
            return $this->setFormatData(API_ERROR_INTEREST_TEMPLATE);
        }

        $product['interest_template'] = $interestTemplate;
        if(!empty(static::$appCdn)){
            $icon = $product['icon'];
            $product['icon'] = str_replace('cdn.sup-pocket.id', static::$appCdn, $icon);
        }
        $jumpUrl = $product['jump_url'];
        $jumpUrl = \Yii::$app->api->getAfLink($jumpUrl, static::$guid, static::$androidId, static::$params['deviceInfo']['gaid'], static::$appSiteid);
        $product['jump_url'] = $jumpUrl;
        $product['is_login'] = static::$isLogin;
        return $this->setFormatData(API_SUCCESS, $product);
    }

    public function actionDetails()
    {
        if (empty(self::$params['pid'])) {
            return $this->setFormatData(API_ERROR_PRODUCT_ID);
        }
        $pid = self::$params['pid'];

        $details = ProductCashLoanDetails::find()->where('pid = :id', [':id' => $pid])->limit(1)->asArray()->one();
        if (empty($details)) {
            return $this->setFormatData(API_ERROR_PRODUCT_ID);
        }

        if (!empty($details['area'])) {
            $areaId = explode(',', $details['area']);
            $areaName = ProductArea::getListName($areaId);
            $areaNameStr = implode(',', $areaName);
            $details['area'] = $areaNameStr;
        }

        if (!empty($details['repayment_type'])) {
            $repayTypeId = explode(',', $details['repayment_type']);
            $repayTypeName = ProductRepayType::getListName($repayTypeId);
            $repayTypeStr = implode(',', $repayTypeName);
            $details['repayment_type'] = $repayTypeStr;
        }

        return $this->setFormatData(API_SUCCESS, $details);
    }

    /**
     * 获取 banner
     * @return array
     */
    public function actionGetBanner(): array
    {
        $resource = ProductResource::find()
            ->select(['product_name', 'package_name', 'resource_url', 'redirect_url', 'redirect_type'])
            ->where(['and',['status' => 1], ['resource_type' => 1], ['like', 'app_package', static::$appPackage]])
            ->orderBy(['sort' => SORT_ASC])
            ->asArray()
            ->all();
        $product_cash_loan = ProductCashLoan::find()
            ->select(['id'])
            ->status()
            ->column();
        foreach ($resource as $key => $item) {
            /* 替换 CDN 链接 */
            $resource[$key]['resource_url'] = ProductCashLoan::replaceCdn($item['resource_url'], static::$appCdn);
            /* 未上架产品 不显示 */
            if ($item['redirect_type'] === '1' && !in_array($item['redirect_url'], $product_cash_loan, true)) {
                unset($resource[$key]);
            }
        }// End Foreach

        return $this->setFormatData(API_SUCCESS, array_values($resource));
    }

    /**
     * 获得apk产品列表信息
     * @return array
     */
    public function actionGetAkList(){

        $data = ProductCashLoan::find()
            ->select([
                'id',
                'appid',
                'product_name as productName',
                'interest_rate as interestRate',
                'interest_rate_unit as interestRateUnit',
                'loan_time_day as loanDay',
                'price_min as priceMin',
                'price_max as priceMax',
                'price_unit as priceUnit',
                'icon',
                'total_score as totalScore',
                'review',
                'package_name as packageName',
                'api_status',
                'cap_limit as capLimit',
            ])
            ->where('status=1 and apk_status=1')
            ->andWhere(['like', 'show_apps', self::$appPackage])
            ->orderBy('sort asc, method_sort desc')
            ->asArray()->all();
        /** 剔除达到cap的产品 */
        $product_list_cap = [];
        foreach ($data as $item) {
            if($item['capLimit'] > 0){
                //获取实时安装
                $realtimeCount = ProductCashLoan::getProductRealtimeInstalls($item['packageName'], date('Y-m-d'));
                if($realtimeCount < $item['capLimit']){
                    $product_list_cap[] = $item;
                }
            }else{
                $product_list_cap[] = $item;
            }
        }
        $data = $product_list_cap;
        return $this->setFormatData(API_SUCCESS, $data);
    }
}
