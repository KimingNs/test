<?php


namespace api\controllers;


use common\models\AppList;
use common\models\RedisCache\SignUpPopUpsCache;
use common\models\SmsCode;
use common\models\User;
use common\models\UserInfo;

class UserController extends ApiRest
{
    /**
     * 注册短信验证码
     * @param string mobile
     * @param string appPackage
     * @param string guid
     * @return array setFormatData
     */
    public function actionSignUpSms()
    {
        $mobile = parent::$params['mobile'];
        list($mobile,$api_code) = \Yii::$app->validate->mobile($mobile);
        if ($mobile === null) {
            return $this->setFormatData($api_code);
        }

        $app_package = parent::$params['appPackage'];
        $app_name = AppList::find()->select(['app_name'])->where(['app_package'=>$app_package])->asArray()->scalar();
        if (empty($app_name)) {
            return $this->setFormatData(API_ERROR_PACKAGE);
        }

        $exists = UserInfo::userExists($app_package,$mobile);
        if ($exists) {
            return $this->setFormatData(VALIDATE_ERROR_MOBILE_EXISTS);
        }

        $guid = parent::$params['guid'];

        $send_message = \Yii::$app->sms->sendCode($guid,$app_name,$mobile,'sign-up');
        return $this->setFormatData($send_message);
    }

    /**
     * 注册
     * @param string guid
     * @param string mobile
     * @param string appPackage
     * @return array setFormatData
     */
    public function actionSignUp()
    {
        $guid = parent::$params['guid'];

        $mobile = parent::$params['mobile'];
        list($mobile,$api_code) = \Yii::$app->validate->mobile($mobile);
        if ($mobile === null) {
            return $this->setFormatData($api_code);
        }

        $app_package = parent::$params['appPackage'];
        $app_name = AppList::find()->select(['app_name'])->where(['app_package'=>$app_package])->asArray()->scalar();
        if (empty($app_name)) {
            return $this->setFormatData(API_ERROR_PACKAGE);
        }

        $exists = UserInfo::userExists($app_package,$mobile);
        if ($exists) {
            return $this->setFormatData(VALIDATE_ERROR_MOBILE_EXISTS);
        }

        $password = parent::$params['password'];
        list($validate,$api_code,$message) = \Yii::$app->validate->password($password);
        if (!$validate) {
            return $this->setFormatData($api_code,'',$message);
        }
        $password = md5($password);

        $code = parent::$params['code'];
        list($exists,$api_code) = SmsCode::codeExists($app_name,$mobile,'sign-up',$code);
        if (!$exists) {
            return $this->setFormatData($api_code);
        }

        list($api_code,$data) = UserInfo::userInsert($app_package,$mobile,$password,$guid);
        return $this->setFormatData($api_code,$data);
    }

    /**
     * 登录
     * @param string appPackage
     * @param string mobile
     * @param string password
     * @return array setFormatData
     */
    public function actionSignIn()
    {
        $app_package = parent::$params['appPackage'];

        $mobile = parent::$params['mobile'];
        list($mobile,$api_code) = \Yii::$app->validate->mobile($mobile);
        if ($mobile === null) {
            return $this->setFormatData($api_code);
        }

        $password = parent::$params['password'];
        list($validate,$api_code,$message) = \Yii::$app->validate->password($password);
        if (!$validate) {
            return $this->setFormatData($api_code,'',$message);
        }
        $password = md5($password);

        list($api_code,$data) = UserInfo::validatePassword($app_package,$mobile,$password);
        return $this->setFormatData($api_code,$data);
    }

    /**
     * 忘记密码验证码
     * @param string mobile
     * @param string appPackage
     * @param string guid
     * @return array setFormatData
     */
    public function actionForgotPasswordSms()
    {
        $mobile = parent::$params['mobile'];
        list($mobile,$api_code) = \Yii::$app->validate->mobile($mobile);
        if ($mobile === null) {
            return $this->setFormatData($api_code);
        }

        $app_package = parent::$params['appPackage'];
        $app_name = AppList::find()->select(['app_name'])->where(['app_package'=>$app_package])->asArray()->scalar();
        if (empty($app_name)) {
            return $this->setFormatData(API_ERROR_PACKAGE);
        }

        $exists = UserInfo::userExists($app_package,$mobile);
        if (!$exists) {
            return $this->setFormatData(VALIDATE_ERROR_MOBILE_NOT_EXISTS);
        }

        $guid = parent::$params['guid'];

        $send_message = \Yii::$app->sms->sendCode($guid,$app_name,$mobile,'forgot-password');
        return $this->setFormatData($send_message);
    }

    /**
     * 忘记密码
     * @param string mobile
     * @param string appPackage
     * @param string password
     * @param string code
     * @param string guid
     * @return array setFormatData
     */
    public function actionForgotPassword()
    {
        $mobile = parent::$params['mobile'];
        list($mobile,$api_code) = \Yii::$app->validate->mobile($mobile);
        if ($mobile === null) {
            return $this->setFormatData($api_code);
        }

        $app_package = parent::$params['appPackage'];
        $app_name = AppList::find()->select(['app_name'])->where(['app_package'=>$app_package])->asArray()->scalar();
        if (empty($app_name)) {
            return $this->setFormatData(API_ERROR_PACKAGE);
        }

        $exists = UserInfo::userExists($app_package,$mobile);
        if (!$exists) {
            return $this->setFormatData(VALIDATE_ERROR_MOBILE_NOT_EXISTS);
        }

        $password = parent::$params['password'];
        list($validate,$api_code,$message) = \Yii::$app->validate->password($password);
        if (!$validate) {
            return $this->setFormatData($api_code,'',$message);
        }
        $password = md5($password);

        $code = parent::$params['code'];
        list($exists,$api_code) = SmsCode::codeExists($app_name,$mobile,'forgot-password',$code);
        if (!$exists) {
            return $this->setFormatData($api_code);
        }

        $guid = parent::$params['guid'];

        UserInfo::editPassword($app_package,$mobile,$password,$guid);
        return $this->setFormatData(API_SUCCESS);
    }

    public function actionSignOut()
    {

    }

    /**
     * 是否 注册弹窗
     * @return array
     */
    public function actionSignUpPopUps(): array
    {
        $pop_ups = false;
        return $this->setFormatData(API_SUCCESS, $pop_ups);

        $is_gp = AppList::find()->select(['is_gp'])->where(['app_package'=>static::$appPackage])->asArray()->scalar();
        if ($is_gp !== '2') { //马甲包审核中 不弹窗
            $date = date('Y-m-d');
            $exists = SignUpPopUpsCache::find()->where(['date'=>$date, 'app_package' => static::$appPackage, 'guid' => static::$guid])->exists();
            if (!$exists) {
                $model = new SignUpPopUpsCache();
                $model->setAttributes([
                    'date' => $date,
                    'app_package' => static::$appPackage,
                    'guid' => static::$guid,
                ], false);
                $model->save();
                $pop_ups = true;
            }
        }
        return $this->setFormatData(API_SUCCESS, $pop_ups);
    }
}