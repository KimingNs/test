<?php


namespace api\controllers;


use common\models\log\LogApkChannelClick;
use yii\web\Controller;

class ChannelController extends Controller
{
    public function actionPackage()
    {
        $request = \Yii::$app->request->get();
        $channel = isset($request['c']) ? $request['c'] : '';
        $click_id = isset($request['click_id']) ? $request['click_id'] : '';
        $channels = \Yii::$app->params['channels'];
        $redirect = (isset($request['c']) && isset($channels[$request['c']])) ? $channels[$request['c']]['redirect'] : '';
        try {
            LogApkChannelClick::getDb()->createCommand()->insert(LogApkChannelClick::tableName(),[
                'channel' => $channel,
                'click_id' => $click_id,
                'redirect_url' => $redirect,
            ])->execute();
        } catch (\Exception $e) {
            \Yii::error($e);
        }

        $this->redirect($redirect,302);
    }
}