<?php


namespace api\controllers;


use common\models\ChuanglanSms;
use yii\base\Controller;

class ChuanglanSmsController extends Controller
{
    /***
     * 发送短信
     * @return mixed
     */
    public function actionSendInternational()
    {
        $post = \Yii::$app->request->post();

        $response = \Yii::$app->ChuanglanSms->sendInternational($post['mobile'], $post['msg']);
        if(!is_null(\GuzzleHttp\json_decode($response))){
            $output=\GuzzleHttp\json_decode($response,true);
            if(isset($output['code'])  && $output['code']=='0'){
                echo '短信发送成功！' . PHP_EOL;
            }else{
                echo $output['error'] . PHP_EOL;
            }
        }else{
            echo $response . PHP_EOL;
        }

        $chuanglan_sms = new ChuanglanSms();
        $chuanglan_sms->action = 'send-international';
        $chuanglan_sms->request = \GuzzleHttp\json_encode($post, JSON_UNESCAPED_UNICODE);
        $chuanglan_sms->response = $response;
        $chuanglan_sms->save();
        return $response;
    }

    /***
     * 查询额度
     * @return mixed
     */
    public function actionQueryBalance()
    {
        $response = \Yii::$app->ChuanglanSms->queryBalance();
        if(!is_null(\GuzzleHttp\json_decode($response))){
            $output=\GuzzleHttp\json_decode($response,true);
            if(isset($output['code'])  && $output['code']=='0'){
                echo '余额	' . $output['balance'].'	元' . PHP_EOL ;
            }else{
                echo $output['error'] . PHP_EOL;
            }
        }else{
            echo $response . PHP_EOL;
        }
        $chuanglan_sms = new ChuanglanSms();
        $chuanglan_sms->action = 'query-balance';
        $chuanglan_sms->request = '';
        $chuanglan_sms->response = $response;
        $chuanglan_sms->save();
        return $response;
    }

    /**
     * 下发回调
     */
    public function actionSendCallback()
    {
        $get = \Yii::$app->request->get();
        $chuanglan_sms = new ChuanglanSms();
        $chuanglan_sms->action = 'send-callback';
        $chuanglan_sms->request = \GuzzleHttp\json_encode($get);
        $chuanglan_sms->save();
    }

    /**
     * 上行回调
     */
    public function actionPushCallback()
    {
        $get = \Yii::$app->request->get();
        $chuanglan_sms = new ChuanglanSms();
        $chuanglan_sms->action = 'push-callback';
        $chuanglan_sms->request = \GuzzleHttp\json_encode($get);
        $chuanglan_sms->save();
    }
}