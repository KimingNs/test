<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/4
 * Time: 上午10:50
 */

namespace api\controllers;


use GuzzleHttp\Client;
use yii\web\Controller;

class TestController extends Controller
{
    public function actionIndex()
    {
        $cache = \Yii::$app->cache->get('test');
        var_dump($cache);
        if($cache === false){
            \Yii::$app->cache->set('test','test1',5);
        }

        $data = [
            'guid' => 'ea361d4afec7b71d80e90d9361d5a9e7',
            'appType' => 'android',
            'appVersion' => 1,
            'channel' => 'app',
            'sign' => '',
            'timestamp' => '',
            'appPackage' => 'test.cash.id',
            'deviceInfo' => [
                'andId' => '1234567890',
                'gaid' => 'asd123456',
                'imei' => 'zxcasd9990',
                'mac' => 'aaabbbccc',
                'model' => 'FX',
                'brand' => 'SHANXING',
                'version' => '18',
            ],
            'packageList' => [
                0 => 'id.dulu.utang',
                1 => 'com.usaku.sx',
                2 => 'id.poqhy.popflash',
                3 => 'test.cash4.id',
                4 => 'test.cash5.id',
            ]
        ];
        $time = time();
        $key = '123456';
        $sign = \Yii::$app->api->getSign($key, $data, $time);
        $data['timestamp'] = $time;
        $data['sign'] = $sign;
        $client = new Client();
        $res = $client->post(
        //'http://localhost:8888/user-device/get-guid',
        //'http://localhost:8888/user-package/upload-package',
            'http://api.lioncash.id/user-device/get-guid',
            [
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json'
                ],
                'json' => $data,
                'form_params' => [
                    'data' => json_encode($data)
                ],
                'timeout' => 5
            ]
        );
        $code = $res->getStatusCode();
        var_dump($code);
        echo '<br/>';
        echo '<br/>';
        echo '<br/>';
        $phrase = $res->getReasonPhrase();
        var_dump($phrase);
        echo '<br/>';
        echo '<br/>';
        echo '<br/>';
        $body = $res->getBody();
        $stringBody = (string)$body;
        var_dump($stringBody);

    }
}