<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/7
 * Time: 下午6:16
 */

namespace api\controllers;

use common\models\AppList;
use common\models\log\LogApkChannelClick;
use common\models\UserDevice;
use common\models\UserDevicePackage;

class UserDeviceController extends ApiRest
{
    //获取用户设备的GUID
    public function actionGuids()
    {
        if (empty(static::$params['deviceInfo'])) {
            return $this->setFormatData(API_ERROR_DEVICE_EMPTY);
        }

        $guid = \Yii::$app->api->getGuid(static::$params['deviceInfo']);
        if(empty(static::$guid)){
            static::$guid = $guid;
        }

        if ($guid === false) {
            \Yii::error('无法生成GUID，params=' . json_encode(static::$params));
            return $this->setFormatData(API_ERROR_CREATE_GUID);
        }

        UserDevice::setTableName($guid);
        $userDevice = UserDevice::find()
            ->select(['id'])
            ->where('guid = :id', [':id' => $guid])
            ->asArray()->one();

        if (!empty($userDevice)) {
            //在马甲包表保存设备ID
            $this->saveGuidPackage($guid);
            return $this->setFormatData(API_SUCCESS, ['guid' => $guid]);
        }

        try {
            $userDevice = new UserDevice();
            $userDevice::setTableName($guid);
            $save = $userDevice->saveDeviceInfo($guid, static::$params);
            if ($save !== false) {
                //在马甲包表保存设备ID
                $this->saveGuidPackage($guid);
                $this->installToChannel(static::$channel);
                return $this->setFormatData(API_SUCCESS, ['guid' => $guid]);
            } else {
                return $this->setFormatData(API_ERROR_SERVER);
            }
        } catch (\Exception $e) {
            \Yii::error($e);
            UserDevice::setTableName($guid);
            $userDevice = UserDevice::find()
                ->select(['id', 'guid'])
                ->where('guid = :id', [':id' => $guid])
                ->asArray()->one();
            //在马甲包表保存设备ID
            $this->saveGuidPackage($guid);
            return $this->setFormatData(API_SUCCESS, ['guid' => $userDevice['guid']]);
        }
    }

    //把GUID保存到对应的马甲包表
    private function saveGuidPackage($guid)
    {
        $appName = AppList::getAppName(static::$appPackage);
        if (empty($appName)) {
            \Yii::error('包名：' . static::$appPackage . '，查下不到对应的APP名称。');
            return false;
        }
        UserDevicePackage::setTableName($appName);
        $userDevicePackage = UserDevicePackage::find()->select(['id'])->where('guid = :id', [':id' => $guid])->limit(1)->asArray()->one();
        if (!empty($userDevicePackage)) {
            return true;
        }

        try {
            $userDevicePackage = new UserDevicePackage();
            $userDevicePackage::setTableName($appName);
            $userDevicePackage->guid = $guid;
            $userDevicePackage->user_id = static::$userId;
            $userDevicePackage->app_package = isset(static::$appPackage) ? static::$appPackage : '';
            $userDevicePackage->app_version = isset(static::$appVersion) ? static::$appVersion : '';
            $userDevicePackage->channel = isset(static::$params['channel']) ? static::$params['channel'] : '';
            $userDevicePackage->af_channel = isset(static::$params['afChannel']) ? static::$params['afChannel'] : '';
            $userDevicePackage->save();
            return true;
        } catch (\Exception $e) {
            \Yii::error($e);
            return false;
        }
    }

    //将渠道的安装数据提交给渠道
    private function installToChannel($channel)
    {
        $channels = \Yii::$app->params['channels'];
        $callbackUrl = isset($channels[$channel]['post_back']) ? $channels[$channel]['post_back'] : '';
        if (empty($callbackUrl)) { return false; }

        $model = new LogApkChannelClick();
        $model::setTableName(date('ymd'));
        do {
            $click = $model::find()
                ->where(['channel' => $channel,'post_back_status' => 0])
                ->orderBy(['id' => SORT_DESC])
                ->one();
            if (empty($click)) { return false; }
            $callbackUrl = str_replace('{click_id}',$click->click_id,$callbackUrl);
            $click->post_back_status = 1;
            $click->post_back_url = $callbackUrl;
            $result = $click->save();
        } while (!$result);

        $client = new \GuzzleHttp\Client();
        $response = $client->requestAsync('GET',$callbackUrl);
        //$resultBody = $response->getBody()->getContents();
        //$result = \GuzzleHttp\json_decode($resultBody,true);
        return true;
    }
}