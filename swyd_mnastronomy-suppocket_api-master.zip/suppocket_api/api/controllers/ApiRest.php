<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/4
 * Time: 上午11:28
 */

namespace api\controllers;

use api\models\log\LogAppApi;
use common\models\AppList;
use common\models\log\LogActiveUsers;
use common\models\UserDevicePackage;
use yii\rest\Controller;

class ApiRest extends Controller
{

    //开始运行时间
    public static $actionStart = null;

    //API接口统一用该属性返回
    public $restData = array();
    //用户ID
    public static $userId = '';
    //用户的guid
    public static $guid = '';
    //安卓ID
    public static $androidId = '';
    //版本
    public static $appVersion = 0;
    //API接口参数
    public static $params = [];
    //渠道
    public static $channel = null;

    public static $ip = null;

    public static $requestTime = null;

    public static $appPackage = null;

    public static $appCdn = null;

    public static $appSiteid = null;

    public static $ref = '';

    public static $appName = '';

    public static $isLogin = 0;

    public function beforeAction($action)
    {
        //统计接口运行时间，记录开始时间
        static::$actionStart = microtime(true);

        static::$requestTime = date('Y-m-d H:i:s');
        try {
            parent::beforeAction($action);
            //设置language语言
            \Yii::$app->language = API_LANGUAGE;
            //设置返回的内容的格式，该格式为JSON
            \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $res = $this->validate($action);
            if ($res === true) {
                $this->setFormatData(API_SUCCESS);
                return true;
            } else {
                //验证失败，返回错误码
                \Yii::$app->response->data = $this->restData;
                //添加接口日志
                $this->addLogApi($action);
                return false;
            }
        } catch (\Exception $e) {
            $this->addLogApi($action);
            \Yii::error($e);
            return false;
        }
    }


//    //验证登录接口相关参数
    public function validate($action)
    {
        $userIp = $_SERVER['HTTP_X_REAL_IP'];
        if(empty($userIp)){
            $userIp = \Yii::$app->request->getUserIP();
        }
        static::$ip = $userIp;
        //获取POST过来的所有参数
        try {
//            $params = json_decode(\Yii::$app->request->post('data'), true);
            $params = \Yii::$app->request->post();
        } catch (\Exception $e) {
            \Yii::error($e);
            $this->setFormatData(API_ERROR_NOT_JSON);
            return false;
        }
        if (empty($params)) {//为空则返回错误码
            $res = $this->setFormatData(API_ERROR_PARAM_EMPTY);
            return false;
        }
        static::$params = $params;
        //判断appType参数是否为空
        if (empty(static::$params['appType']) || static::$params['appType'] != 'android') {
            $this->setFormatData(API_ERROR_APPTYPE);
            return false;
        }
        //判断版本是否为空参数是否为空
        if (empty(static::$params['appVersion'])) {
            $this->setFormatData(API_ERROR_VERSION);
            return false;
        }
        static::$appVersion = static::$params['appVersion'];

        //判断渠道是否为空
        if (empty(static::$params['channel'])) {
            $this->setFormatData(API_ERROR_CHANNEL);
            return false;
        }

        //判断sign参数是否为空
        if (empty(static::$params['sign'])) {
            $this->setFormatData(API_ERROR_SIGN);
            return false;
        }

        //判断timestamp参数是否为空
        if (empty(static::$params['timestamp'])) {
            $this->setFormatData(API_ERROR_TIMESTAMP);
            return false;
        }

        //判断包名参数是否为空
        $appList = AppList::getAppList();
        if (empty(static::$params['appPackage']) || empty($appList[static::$params['appPackage']])) {
            $this->setFormatData(API_ERROR_APP_PACKAGE);
            return false;
        }

        static::$appPackage = static::$params['appPackage'];

        static::$userId = isset(static::$params['userId']) ? static::$params['userId'] : '';

        static::$guid = isset(static::$params['guid']) ? static::$params['guid'] : '';

        static::$appCdn = $appList[static::$params['appPackage']]['app_cdn'];

        static::$appSiteid = $appList[static::$params['appPackage']]['site_id'];

        static::$channel = isset(static::$params['channel']) ? static::$params['channel'] : '';

        static::$ref = isset(static::$params['ref']) ? static::$params['ref'] : '';

        static::$appName = $appList[static::$params['appPackage']]['app_name'];

        static::$isLogin = $appList[static::$params['appPackage']]['is_login'];

        $appKey = $appList[static::$params['appPackage']]['app_key'];

        $sign = \Yii::$app->api->getSign($appKey, static::$params, static::$params['timestamp']);
        if ($sign != static::$params['sign']) {
            $this->setFormatData(API_ERROR_SIGN);
            return false;
        }

        self::$androidId = static::$params['deviceInfo']['andId'];
        return true;
    }


    //设置返回的RestData的Code及Message
    public function setFormatData($code, $data = '',$msg='')
    {
        $this->restData['code'] = $code;
//        $this->restData['msg'] = \Yii::t('api', $code);
        $this->restData['msg'] = $msg;
        $this->restData['data'] = $data;
        return $this->restData;
    }

    //添加接口日志
    public function addLogApi($action)
    {
        try {
            $api_name = $action->controller->id . '/' . $action->id;
            $return = isset($this->restData) ? json_encode($this->restData) : '';
            $code = isset($this->restData['code']) ? $this->restData['code'] : '';

            $log = new LogAppApi();
            $log->api_name = $api_name;
            $log->user_id = isset(static::$params['userId']) ? static::$params['userId'] : '';
            $log->ip = static::$ip;
            $log->code = $code;
            $log->request_time = static::$requestTime;
            $endTime = microtime(true);
            $log->process_time = ($endTime - static::$actionStart);
            $log->prarm = json_encode(static::$params);
            $log->return = $return;
            $log->app_package = static::$params['appPackage'];
            $log->save();

        } catch (\Exception $e) {
            \Yii::error($e);
        }
        return true;
    }

    //在所有逻辑代码执行完后执行该方法
    public function afterAction($action, $result)
    {
        static::addActiveUser($action);
        static::updateDeviceRef($action);
        //添加接口日志
        $this->addLogApi($action);
        return parent::afterAction($action, $result);
    }

    public static function addActiveUser($action)
    {
        $activeUsers = new LogActiveUsers();
        $activeUsers->guid = static::$guid;
        try {
            $activeUsers->class = $action->controller->id;
            $activeUsers->function = $action->id;
            $activeUsers->android_id = static::$androidId;
            $activeUsers->gaid = isset(static::$params['deviceInfo']['gaid']) ? static::$params['deviceInfo']['gaid'] : '';
            $activeUsers->ip = static::$ip; //获取ip地址
            $activeUsers->position = isset(static::$params['position']) ? static::$params['position'] : '';
            $activeUsers->imei = isset(static::$params['deviceInfo']['imei']) ? static::$params['deviceInfo']['imei'] : '';
            $activeUsers->sn = isset(static::$params['deviceInfo']['sn']) ? static::$params['deviceInfo']['sn'] : '';
            $activeUsers->model = isset(static::$params['deviceInfo']['model']) ? static::$params['deviceInfo']['model'] : '';
            $activeUsers->brand = isset(static::$params['deviceInfo']['brand']) ? static::$params['deviceInfo']['brand'] : '';
            $activeUsers->version = isset(static::$appVersion) ? static::$appVersion : 1;
            $activeUsers->channel = isset(static::$params['channel']) ? static::$params['channel'] : '';
            $activeUsers->app_package = static::$appPackage;
            $activeUsers->save();
            return true;
        } catch (\Exception $e) {
            \Yii::error($e);
            return false;
        }
    }

    public static function updateDeviceRef($action){
        if(empty(static::$ref) || empty(static::$appName) || empty(self::$guid)){
            return false;
        }
        try{
            UserDevicePackage::setTableName(static::$appName);
            $userDevicePackage = UserDevicePackage::find()->select(['id','ref'])->where('guid = :id', [':id' => static::$guid])->limit(1)->one();
            if (empty($userDevicePackage)) {
                return false;
            }
            if(empty($userDevicePackage->ref)){
                $userDevicePackage->ref = static::$ref;
                $userDevicePackage->save();
                return true;
            }
            return false;
        }catch (\Exception $e){
            \Yii::error($e);
            return false;
        }
    }

}