<?php


namespace api\controllers;


use common\models\log\LogProductClick;
use common\models\product\ProductCashLoan;

class StatisticController extends ApiRest
{
    /***
     * 产品点击统计
     * $click_type integer 1-打开链接 | 2-打开APP
     * @return array|int
     */
    public function actionProductClick()
    {
        $pid = parent::$params['pid'];
        $product = ProductCashLoan::find()->where(['id'=>$pid])->asArray()->one();
        if (empty($pid) || empty($product)) {
            return $this->setFormatData(API_ERROR_PRODUCT_ID);
        }
        $click_type = parent::$params['click_type'];
        if (empty($click_type)) {
            return $this->setFormatData(API_ERROR_CLICK_TYPE);
        }

        try {
            $insert_model = new LogProductClick();
            $insert_model->user_id = parent::$params['userId'];
            $insert_model->guid = parent::$params['guid'];
            $insert_model->pid = $pid;
            $insert_model->product_type = 1;
            $insert_model->product_name = $product['product_name'];
            $insert_model->type = $click_type;
            $insert_model->source = null;
            $insert_model->version = parent::$params['appVersion'];
            $insert_model->date = date('Y-m-d');
            $insert_model->app_package = parent::$params['appPackage'];
            $insert_model->save();
            return $this->setFormatData(API_SUCCESS);
        } catch (\Exception $e) {
            \Yii::error($e->getMessage());
            return $this->setFormatData(API_ERROR_SERVER);
        }
    }
}