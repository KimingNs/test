<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/7
 * Time: 下午5:02
 */

namespace api\controllers;


class IndexController extends ApiRest
{
    public function actionIndex()
    {
        return ['code' => 0, 'msg' => 'success', 'data' => ''];
    }
}