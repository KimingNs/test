<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/8
 * Time: 上午11:51
 */

namespace api\controllers;


use common\models\EventPlan;
use common\models\EventReceive;
use common\models\log\LogProductClick;
use common\models\log\LogUserProductInstalled;
use common\models\log\LogUserProductPackage;
use common\models\AppList;
use common\models\product\ProductCashLoan;
use common\models\RedisCache\GpInstalledCache;
use common\models\UserDevice;
use common\models\UserDevicePackage;
use common\models\UserInfo;

class UserPackageController extends ApiRest
{
    public function actionUpPackages()
    {
        if (empty(parent::$params['guid'])) {
            return $this->setFormatData(API_ERROR_GUID);
        }
        if (empty(parent::$params['appPackage'])) {
            return $this->setFormatData(API_ERROR_APP_PACKAGE);
        }
        $package_list = parent::$params['packageList'];
        if (empty($package_list)) {
            return $this->setFormatData(API_ERROR_DEVICE_PACKAGE);
        }
        if (!is_array($package_list)) {
            return $this->setFormatData(API_ERROR_DEVICE_PACKAGE);
        }

        /***
         * @todo 更新用户当前 App List
         */
        //查询用户设备信息
        UserDevice::setTableName(parent::$params['guid']);
        $userDevice = UserDevice::find()->select(['id', 'package_name'])->where('guid = :id', [':id' => parent::$params['guid']])->one();
        if (empty($userDevice)) {
            return $this->setFormatData(API_ERROR_GUID);
        }
        //  更新用户 已安装 App list
        $package_name = $userDevice->package_name;
        $userDevice->package_name = implode(',', $package_list);
        $userDevice->save();

        /***
         * @todo 更新用户当前 app version
         */
        //根据 包名 查出 APP名称
        $appName = AppList::find()->select(['app_name'])->where(['app_package' => parent::$params['appPackage']])->asArray()->scalar();
        if (empty($appName)) {
            return $this->setFormatData(API_ERROR_APP_PACKAGE);
        }
        //根据 APP 名称，定位 t_user_device_appName 表名
        UserDevicePackage::setTableName($appName);
        $userDevicePackage = UserDevicePackage::find()->where( ['guid' => parent::$params['guid']])->one();
        //更新 t_user_device_appName 版本号
        if ($userDevicePackage->app_version != parent::$params['appVersion']) {
            $userDevicePackage->app_version = parent::$params['appVersion'];
            $userDevicePackage->save();
        }

        /***
         * @todo 筛选最新 安装 和 卸载，保存 log
         */
        $product_list = ProductCashLoan::find()
            ->select(['id','product_name','package_name'])
            ->where(['status'=>1])
            ->indexBy('package_name')
            ->asArray()
            ->all();
        $all_package_list = array_keys($product_list);
        $new_package_list = $package_list;
        $old_package_list = explode(',',$package_name);
        //  保存 安装|卸载 日志
        $install = array_intersect($all_package_list, array_diff($new_package_list, $old_package_list));
        $uninstall = array_intersect($all_package_list, array_diff($old_package_list, $new_package_list));
        if (!empty($install)) {
            //归因
            foreach ($install as $value) {
                $pid = $product_list[$value]['id'];
                $product_name = $product_list[$value]['product_name'];
                $package_name = $product_list[$value]['package_name'];
                $this->processProductInstalled($pid,$product_name,$package_name);
            }

            $install = $this->addLogData($install, $product_list,1);
            LogUserProductPackage::insertRows($install);
        }
        if (!empty($uninstall)) {
            $uninstall = $this->addLogData($uninstall, $product_list,2);
            LogUserProductPackage::insertRows($uninstall);
        }

        return $this->setFormatData(API_SUCCESS);
    }

    private function addLogData($package_list,$product_list,$action)
    {
        $func = function ($carry,$item) use ($action,$product_list) {
            $carry[] = [
                parent::$params['userId'],
                parent::$params['guid'],
                $product_list[$item]['id'],
                1,
                $product_list[$item]['product_name'],
                $product_list[$item]['package_name'],
                $action,
                parent::$params['appPackage'],
            ];
            return $carry;
        };
        return array_reduce($package_list,$func);
    }

    private function processProductInstalled($pid,$product_name,$package_name)
    {
        /***
         * 归因期内 是否有点击
         * @params $click bool
         */
        $i = 0;
        do {
            $click_log = new LogProductClick();
            $click_log::setTableName(date('ymd',strtotime("-$i day")));
            $table_exists = $click_log::getDb()->createCommand("SHOW TABLES LIKE '" . $click_log::tableName() . "'")->queryAll();
            if ($table_exists) {
                $click = $click_log::find()
                    ->where(['guid' => parent::$params['guid'], 'pid' => $pid])
                    ->asArray()
                    ->exists();
            }
            $i++;
        } while (!$click && $i<INSTALLED_ATTRIBUTION_DAY);
        if (!$click) {
            //没有点击则不继续
            return false;
        }
        /***
         * 归因期内 是否有下载历史 更新||保存安装时间
         */
        $installed = LogUserProductInstalled::find()
            ->where(['guid'=>parent::$params['guid'],'pid'=>$pid])
            ->one();
        if (empty($installed)) {
            try {
                $model = new LogUserProductInstalled();
                $model->setAttributes([
                    'user_id' => parent::$params['userId'],
                    'guid' => parent::$params['guid'],
                    'pid' => $pid,
                    'product_name' => $product_name,
                    'product_type' => 1,
                    'package_name' => $package_name,
                    'app_package' => parent::$params['appPackage'],
                ], false);
                $model->save();
            } catch (\Exception $e) {
                \Yii::error($e->getMessage());
                return false;
            }
        } else {
            $next_uptime = strtotime($installed->uptime) + (ATTRIBUTION_DAY * 24 * 60 * 60);
            if ($next_uptime <= time()) {
                $installed->uptime = date('Y-m-d H:i:s');
                $installed->save();
            } else {
                return false;
            }
        }

        // 这里更新 统计缓存
        $date = date('Y-m-d');
        $condition = ['date'=>$date, 'app_package'=>parent::$params['appPackage'], 'package_name'=>$package_name];
        $model = GpInstalledCache::find()->where($condition)->one();
        if ($model === null) {
            $values = $condition;
            $values['app_name'] = AppList::find()->select(['app_name'])->where(['app_package' => parent::$params['appPackage']])->scalar();
            $values['product_name'] = $product_name;
            $values['installed_count'] = 0;
            $model = new GpInstalledCache();
            $model->setAttributes($values, false);
            $model->save();
        }
        $model->updateCounters(['installed_count' => 1]);

        return true;
    }

    // 安装奖励活动
    public function actionInstallPlan()
    {
        $plan = static::$params['plan'];
        $guid = static::$guid;

        //  response data
        $data = [
            'installed_icon' => [], //已下载 产品icon
            'mobile' => false,
            'receive_status' => 0, // 是否可领取
        ];

        //  查询 手机号
        $data['mobile'] = UserInfo::find()
            ->select(['mobile'])
            ->where(['user_id'=>static::$userId, 'app_package' => static::$appPackage])
            ->scalar();

        //  查询 event
        $event_plan = EventPlan::find()
            ->where(['plan'=>$plan])
            ->asArray()
            ->one();
        if ($event_plan === null) {
            return $this->setFormatData(VALIDATE_ERROR_PLAN,'','not found event');
        }

        // 查询 符合event下载的产品 icon
        $user_event_installed = LogUserProductInstalled::find()
            ->select(['pid'])
            ->where(['and',['guid'=>$guid], ['app_package'=>static::$appPackage], ['between', 'uptime', $event_plan['start_time'], $event_plan['end_time']]])
            ->limit(5)
            ->asArray()
            ->column();
        $product_icon = ProductCashLoan::find()
            ->select(['icon'])
            ->where(['id' => $user_event_installed])
            ->indexBy('id')
            ->asArray()
            ->column();
        foreach ($product_icon as $icon) {
            $data['installed_icon'][] = ProductCashLoan::replaceCdn($icon, static::$appCdn);
        }

        // 是否 已领取 奖励
        $event_receive = EventReceive::find()
            ->where(['guid'=>$guid, 'plan'=>$plan])
            ->exists();
        if ($event_receive) {
            $data['receive_status'] = 2;
        } elseif (count($product_icon) === 5) {
            $data['receive_status'] = 1;
        }

        return $this->setFormatData(API_SUCCESS, $data);
    }

    //领取奖励
    public function actionInstallPlanReceive()
    {
        $plan = static::$params['plan'];
        $guid = static::$guid;

        //  查询 event
        $event_plan = EventPlan::find()
            ->where(['plan'=>$plan])
            ->asArray()
            ->one();
        if ($event_plan === null) {
            return $this->setFormatData(VALIDATE_ERROR_PLAN,'','not found event');
        }

        // 是否 已领取 奖励
        $event_receive = EventReceive::find()
            ->where(['guid'=>$guid, 'plan'=>$plan])
            ->exists();
        if ($event_receive) {
            return $this->setFormatData(VALIDATE_ERROR_RECEIVE, '', 'user received');
        }

        // 查询 符合event下载的产品 icon
        $user_event_installed = LogUserProductInstalled::find()
            ->where(['and',['guid'=>$guid], ['app_package'=>static::$appPackage], ['between', 'uptime', $event_plan['start_time'], $event_plan['end_time']]])
            ->asArray()
            ->all();
        if (count($user_event_installed) < 5) {
            return $this->setFormatData(VALIDATE_ERROR_RECEIVE, '', 'user count receive');
        }

        $model = new EventReceive();
        $model->setAttributes([
            'plan' => $plan,
            'user_id' => static::$userId,
            'guid' => $guid,
        ],false);
        if ($model->save()) {
            return $this->setFormatData(API_SUCCESS, true);
        }

        return $this->setFormatData(API_ERROR_SERVER, '', 'receive failure');
    }
}