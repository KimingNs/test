<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/6
 * Time: 下午2:30
 */

namespace api\models\log;

use common\models\commonDB\CommonLog;

class LogAppApi extends CommonLog
{
    public static $tableName;

    public static function tableName()
    {
        if (empty(self::$tableName)) {
            return 't_log_app_api_' . date('ymd');
        } else {
            return self::$tableName;
        }
    }

    /**
     * 设置活跃用户
     * @param string $ymd 表名后缀
     */
    public static function setTableName($ymd)
    {
        self::$tableName = 't_log_app_api_' . $ymd;
        return self::$tableName;
    }
}