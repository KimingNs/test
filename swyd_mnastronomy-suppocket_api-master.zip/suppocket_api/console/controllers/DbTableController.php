<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/5/9
 * Time: 上午10:32
 */

namespace console\controllers;


use yii\console\Controller;

class DbTableController extends Controller
{
    public function actionCreateUserDevice()
    {
        for ($i = 0; $i < 128; $i++) {
            $res = \Yii::$app->db->createCommand("
DROP TABLE IF EXISTS `t_user_device_".$i."`;
CREATE TABLE `t_user_device_".$i."` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) DEFAULT '' COMMENT '用户ID',
  `guid` varchar(50) NOT NULL,
  `android_id` varchar(150) DEFAULT '' COMMENT '安卓ID',
  `gaid` varchar(150) DEFAULT '' COMMENT 'gaid',
  `imei` varchar(100) DEFAULT '' COMMENT 'imei',
  `mac` varchar(255) DEFAULT '' COMMENT 'mac地址',
  `sn` varchar(100) DEFAULT '' COMMENT 'SN号',
  `model` varchar(100) DEFAULT '' COMMENT '型号',
  `brand` varchar(100) DEFAULT '' COMMENT '品牌',
  `os_version` varchar(50) DEFAULT '' COMMENT '系统版本',
  `sdk_version` varchar(50) DEFAULT '' COMMENT '系统sdk版本',
  `package_name` varchar(5000) DEFAULT '',
  `ctime` datetime DEFAULT CURRENT_TIMESTAMP,
  `uptime` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_root` tinyint(1) DEFAULT '0' COMMENT '0未root，1已root',
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`) USING BTREE,
  KEY `userid` (`user_id`),
  KEY `idx_androidid` (`android_id`),
  KEY `idx_sn` (`sn`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;")
                ->execute();
          var_dump($i);
        }
    }
}