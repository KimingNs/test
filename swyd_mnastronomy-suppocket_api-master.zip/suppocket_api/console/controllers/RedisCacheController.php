<?php


namespace console\controllers;


use common\models\RedisCache\GpInstalledCache;
use common\models\RedisCache\SignUpPopUpsCache;
use yii\console\Controller;

class RedisCacheController extends Controller
{
    public function actionTest(): void
    {
        $query = GpInstalledCache::find()->all();
        foreach ($query as $row) {
            var_dump($row->getAttributes());
        }
    }

    public function actionDeleteCache(): void
    {
        $date = date('Y-m-d');
        GpInstalledCache::deleteAll(['<', 'date', $date]);
        SignUpPopUpsCache::deleteAll(['<', 'date', $date]);
    }

}