<?php
/**
 * Created by PhpStorm.
 * User: zhangyi
 * Date: 2019/4/17
 * Time: 下午5:10
 */

namespace console\controllers;

use common\models\product\ProductArea;
use common\models\product\ProductCashLoanDetails;
use common\models\product\ProductRepayType;
use yii\console\Controller;

class TestController extends Controller
{
    public function actionIndex()
    {
        $pid = 5;
        $details = ProductCashLoanDetails::find()->where('pid = :id', [':id' => $pid])->limit(1)->asArray()->one();

        if (!empty($details['area'])) {
            $areaId = explode(',', $details['area']);
            $areaName = ProductArea::getListName($areaId);
            $areaNameStr = implode(',', $areaName);
            $details['area'] = $areaNameStr;
        }

        if(!empty($details['repayment_type'])){
            $repayTypeId = explode(',', $details['repayment_type']);
            $repayTypeName = ProductRepayType::getListName($repayTypeId);
            var_dump($repayTypeName);
            $repayTypeStr = implode(',', $repayTypeName);
            $details['repayment_type'] = $repayTypeStr;
        }

        var_dump($details);
    }
}