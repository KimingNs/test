<?php

use yii\db\Migration;

/**
 * Class m190606_100419_create_t_user_info
 */
class m190606_100419_create_t_user_info extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('t_user_info',[
            'id' => $this->primaryKey(),
            'app_package' => $this->string()->notNull(),
            'user_id' => $this->string()->notNull(),
            'mobile' => $this->string()->notNull(),
            'user_name' => $this->string()->defaultValue('nick name'),
            'password' => $this->string()->notNull(),
            'logo' => $this->string()->defaultValue(null),
            'first_guid' => $this->string()->notNull(),
            'last_guid' => $this->string()->notNull(),
            'last_active' => $this->dateTime()->notNull(),
            'ctime' => $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP'),
            'uptime' => $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
        ]);
        $this->createIndex('mobile','t_sms_code','mobile');
        $this->createIndex('mobile code','t_sms_code',['mobile','code']);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('t_user_info');
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m190606_100419_create_t_user_info cannot be reverted.\n";

        return false;
    }
    */
}
