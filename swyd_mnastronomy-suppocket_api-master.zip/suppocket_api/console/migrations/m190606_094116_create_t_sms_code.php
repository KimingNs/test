<?php

use yii\db\Migration;

/**
 * Class m190606_094116_create_t_sms_code
 */
class m190606_094116_create_t_sms_code extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('t_sms_code',[
            'id' => $this->primaryKey(),
            'app_name' => $this->string()->notNull(),
            'mobile' => $this->string()->notNull(),
            'action' => $this->string()->notNull(),
            'code' => $this->string()->notNull(),
            'status' => $this->tinyInteger(1)->defaultValue(0),
            'ctime' => $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP'),
            'uptime' => $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'),
        ]);
        $this->createIndex('app mobile','t_sms_code',['app_name','mobile']);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('t_sms_code');
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m190606_094116_create_t_sms_code cannot be reverted.\n";

        return false;
    }
    */
}
